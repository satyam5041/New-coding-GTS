import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PromiselandComponent } from './promiseland.component';

describe('PromiselandComponent', () => {
  let component: PromiselandComponent;
  let fixture: ComponentFixture<PromiselandComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PromiselandComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PromiselandComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
