import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { TooltipPosition } from '@ng-matero/extensions';
import { AnnouncementDialogComponent } from 'src/app/feature/announcement-dialog/announcement-dialog.component';
import { PromiselandDialogComponent } from 'src/app/feature/promiseland-dialog/promiseland-dialog.component';
import { SmallDialogComponent } from 'src/app/feature/small-dialog/small-dialog.component';
import { ApiService } from 'src/app/services/api.service';
import { ExcelService } from 'src/app/services/excel.service';
import { UserDataService } from 'src/app/services/user-data.service';
import { UserDetailsService } from 'src/app/services/user-details.service';
import {environment} from '../../../environments/environment';

export interface UserData {
  id: string;
  name: string;
  progress: string;
  fruit: string;
}

@Component({
  selector: 'app-promiseland',
  templateUrl: './promiseland.component.html',
  styleUrls: ['./promiseland.component.scss']
})
export class PromiselandComponent implements OnInit {


  
  formGroup: FormGroup;
  promiseTypeList:any=[];
 
  // {"sno":"30","id":"5e7780e504ab4","description":"vrvevd
  // ","file_path":"http:\/\/rmeti.com\/pgm-app\/uploads\/PROMISE_SELF\/5e7780e5032b7.png","promise_type":"House","promise_date":"2020-03-22","uniq_id":"5dc05ad4cec9d","status":"0","timestamp":"2020-03-22
  // 08:14:45"}
  displayedColumns: string[] = ['play','title','subtitle','description','type','status','actions'];
  dataSource: MatTableDataSource<UserData>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  dataList:any=[]
  active_status:any="";

  constructor(public dialog: MatDialog,private api:ApiService,private _snackBar: MatSnackBar,private excelService:ExcelService,private userDataService:UserDataService,private userDeatilsService:UserDetailsService) {
    // Create 100 users
    // const users = Array.from({length: 100}, (_, k) => createNewUser(k + 1));

    // Assign the data to the data source for the table to render
    // this.dataSource = new MatTableDataSource(users);
  }
  positionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
  position = new FormControl(this.positionOptions[0]);

 

  ngOnInit(){
    this.getPromises();
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  addPromiseDialog(data:any,editStatus:boolean=false): void {
    console.log("COMP DATA::",data,editStatus)
    let dialogRef = this.dialog.open(PromiselandDialogComponent, {
      width: '50%',
      data: { title: 'Heading', caption: `caption`,message:'Hello Meassag',close_btn:'Close',submit_btn_1:editStatus?'Update & Close':'Save & Close',submit_btn_2:editStatus?'Update & Add New':'Save & Add New',data:data ,promiseTypeList:this.promiseTypeList,editStatus:editStatus}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed',result);
      this.getPromises();
      // this.animal = result;
    });
  }

  getPromises(){

    let url=environment.SERVICE_APIS.getPromises;
    this.userDeatilsService.userInfo.uniq_id="619dc94c253c3";
    this.userDeatilsService.userInfo.global_cid="GP-60C0AB8137F67";
        let params={uniq_id:this.userDeatilsService.userInfo.uniq_id,global_cid:this.userDeatilsService.userInfo.global_cid};
        
        this.api.POST_AUTH_BR(url, params, true)
          .subscribe(
            response => {
              console.log("USER response:::", response);
              // this.dataList=response;
              // this.dataSource = new MatTableDataSource(response['data']);
    this.setData(response);
            },err=>{
              console.log("ERR::",err)
            }
    
          );
      // }
      }
      setData(obj:any){
        console.log("DATA::",obj)
        this.dataList=obj['data'];
        this.promiseTypeList=obj['promiseTypeList'];
        this.dataSource = new MatTableDataSource(obj['data']);
        //this.userDeatilsService.promiseTypeList=obj['promiseTypeList'];
       // this.promiseTypeList=this.userDeatilsService.promiseTypeList;
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      }

    
      getDataByFilter(e:any){
        console.log("data::",this.active_status);
        // this.active_status
        this.getPromises()
      }

      openSnackBar(message: string, action: string) {
        this._snackBar.open(message, action,{
          duration: 3000,
        });
      }

      deleteCountry(obj:any) {
        // this.post = post;
        console.log()
    
        let url=environment.SERVICE_APIS.deleteCountry;
       
        let CREATED_BY=this.userDataService.userDetails.USER_GUID;
            let params={
              "CREATED_BY":CREATED_BY,
              "COUNTRY_GUID":obj.COUNTRY_GUID,
              "ACTIVE_STATUS":obj.ACTIVE_STATUS
            };
            // console.log("DELE::",params)
            // return false;
            this.api.POST_AUTH_BR(url, params, true)
              .subscribe(
                response => {
                  console.log("DELETE response:::", response);
        this.openSnackBar("Deleted success","");
        this.getPromises();
                },err=>{
                  console.log("ERR::",err)
                }
        
              );
    
      }

      deleteCountryDialog(data:any): void {
        let del_status=data.ACTIVE_STATUS?'Active':'Delete';
        let dialogRef = this.dialog.open(SmallDialogComponent, {
          width: '30%',
          data: { title: del_status, caption: ``,message:`Are you sure you want to ${del_status}?`,close_btn:'Close',submit_btn:del_status,data:data,submit_btn_clicked: true}
        });
    
        dialogRef.afterClosed().subscribe(result => {
          console.log('The dialog was closed',result,result.submit_btn_clicked);
if(result.submit_btn_clicked && result.submit_btn_clicked!=undefined){
  this.deleteCountry(result.data);
}
      

          // this.animal = result;
        });
      }
      
      exportAsXLSX():void {
        this.excelService.exportAsExcelFile(this.dataList, 'Promises');
      }


}
