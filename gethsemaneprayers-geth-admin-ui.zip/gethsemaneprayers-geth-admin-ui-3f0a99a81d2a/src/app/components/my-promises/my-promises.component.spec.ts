import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MyPromisesComponent } from './my-promises.component';

describe('MyPromisesComponent', () => {
  let component: MyPromisesComponent;
  let fixture: ComponentFixture<MyPromisesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MyPromisesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MyPromisesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
