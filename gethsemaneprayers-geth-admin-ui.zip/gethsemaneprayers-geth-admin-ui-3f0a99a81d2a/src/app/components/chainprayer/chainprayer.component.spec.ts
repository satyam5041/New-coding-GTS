import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChainprayerComponent } from './chainprayer.component';

describe('ChainprayerComponent', () => {
  let component: ChainprayerComponent;
  let fixture: ComponentFixture<ChainprayerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChainprayerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChainprayerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
