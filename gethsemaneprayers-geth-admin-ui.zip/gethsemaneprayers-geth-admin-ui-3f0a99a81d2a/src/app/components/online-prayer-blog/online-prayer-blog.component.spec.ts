import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OnlinePrayerBlogComponent } from './online-prayer-blog.component';

describe('OnlinePrayerBlogComponent', () => {
  let component: OnlinePrayerBlogComponent;
  let fixture: ComponentFixture<OnlinePrayerBlogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OnlinePrayerBlogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OnlinePrayerBlogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
