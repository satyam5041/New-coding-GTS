import { Component, OnInit } from '@angular/core';
import{FormGroup,FormBuilder,Validators} from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-online-prayer-blog',
  templateUrl: './online-prayer-blog.component.html',
  styleUrls: ['./online-prayer-blog.component.scss']
})
export class OnlinePrayerBlogComponent implements OnInit {
  formGroup: FormGroup;
  comments:any;
  selfBlog:any=[];
  

  constructor(private formBuilder: FormBuilder,private common:CommonService) { }

  ngOnInit(): void {
    this.createForm();
    this.selfBlog=this.common.selfBlog;

    console.log(this.common.selfBlog);
    
  }

  createForm() {
    this.formGroup = this.formBuilder.group({
      'comments': ['', Validators.required],
      
    });
  }
  onSubmit() {
  
  }

}
