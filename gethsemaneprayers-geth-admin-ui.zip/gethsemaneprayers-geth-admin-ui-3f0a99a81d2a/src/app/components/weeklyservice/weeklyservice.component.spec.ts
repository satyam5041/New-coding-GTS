import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WeeklyserviceComponent } from './weeklyservice.component';

describe('WeeklyserviceComponent', () => {
  let component: WeeklyserviceComponent;
  let fixture: ComponentFixture<WeeklyserviceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WeeklyserviceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WeeklyserviceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
