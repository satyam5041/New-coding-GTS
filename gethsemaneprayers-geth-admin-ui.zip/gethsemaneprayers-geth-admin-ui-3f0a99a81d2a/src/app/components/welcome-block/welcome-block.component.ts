import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-welcome-block',
  templateUrl: './welcome-block.component.html',
  styleUrls: ['./welcome-block.component.scss']
})
export class WelcomeBlockComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  welcome:any={
    content:[
      {img:"../assets/images/church_foto.jpg", title:"Welcome", heading:"Loving God, Loving Others and Serving the World", paragraph:"We’d love to meet you! Come check us out this DAY where you can meet us through prayers might be a good fit for you. Our heart and soul is to introduce and connect people with the living and powerful God."}
    ]
  }

  follow:any={
    content:[
      {icon:"las la-heartbeat la-5x text-blue", heading:"Follow with us", paragraph:"We would love to see you and your family & friends this weekend in our church at 10 am."},
      {icon:"las la-bible la-5x text-blue", heading:"What We Believe", paragraph:"We believe that the Bible is God’s Word. It is accurate, authoritative and applicable to our everyday lives."},
      {icon:"las la-user-friends la-5x text-blue", heading:"New Here?", paragraph:"Tell us about yourself to begin your journey with connecting to our community."}
    ]
  }

}
