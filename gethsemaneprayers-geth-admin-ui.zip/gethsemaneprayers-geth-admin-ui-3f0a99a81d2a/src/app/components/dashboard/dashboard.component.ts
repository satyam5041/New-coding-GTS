import { Component, OnInit } from '@angular/core';
import { UserDataService } from 'src/app/services/user-data.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  userDetails:any=[];
  constructor(private userDataService:UserDataService) { 
   this.userDetails=this.userDataService.userDetails;
   console.log("user details::",this.userDetails)
  }
  // tiles: any = [
  //   {text: 'One', cols: 3, rows: 1, color: 'lightblue'},
  //   {text: 'Two', cols: 1, rows: 2, color: 'lightgreen'},
  //   {text: 'Three', cols: 1, rows: 1, color: 'lightpink'},
  //   {text: 'Four', cols: 2, rows: 1, color: '#DDBDF1'},
  // ];
  ngOnInit(): void {
  }

  // dashboard:any={
  //   content:[
  //     {icon:"las la-chess-king la-3x text-blue", heading:"Goals", counts:"123"},
  //     {icon:"las la-pray la-3x text-blue red", heading:"Prayers", counts:"123"},
  //     {icon:"las la-briefcase la-3x text-blue", heading:"Jobs", counts:"123"},
  //     {icon:"las la-praying-hands la-3x text-blue", heading:"Chain Prayers", counts:"123"},
  //     {icon:"las la-network-wired la-3x text-blue", heading:"Connections", counts:"123"},
  //     {icon:"las la-hands-helping la-3x text-blue", heading:"Promises", counts:"123"}
  //   ]
  // }

}
