import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChainPrayersComponent } from './chain-prayers.component';

describe('ChainPrayersComponent', () => {
  let component: ChainPrayersComponent;
  let fixture: ComponentFixture<ChainPrayersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChainPrayersComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChainPrayersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
