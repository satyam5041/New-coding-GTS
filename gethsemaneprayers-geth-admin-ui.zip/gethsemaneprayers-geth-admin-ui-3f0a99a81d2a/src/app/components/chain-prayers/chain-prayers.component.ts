import { Component } from '@angular/core';
import {MatTableDataSource} from '@angular/material/table';


@Component({
  selector: 'app-chain-prayers',
  templateUrl: './chain-prayers.component.html',
  styleUrls: ['./chain-prayers.component.scss']
})
export class ChainPrayersComponent  {

  displayedColumns: string[] = ['position', 'theme', 'start_date', 'start_time','end_date','end_time','slots','add_prayer'];
  dataSource = new MatTableDataSource(ELEMENT_DATA);

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

}

export interface PeriodicElement {
  name: string;
  position: number;
  weight: number;
  symbol: string;
  test: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {position: 1, name: 'Hydrogen', weight: 1.0079, symbol: 'H',test:"ss"},
  {position: 2, name: 'Helium', weight: 4.0026, symbol: 'He',test:"ss"},
  {position: 3, name: 'Lithium', weight: 6.941, symbol: 'Li',test:"ss"},
  {position: 4, name: 'Beryllium', weight: 9.0122, symbol: 'Be',test:"ss"},
  {position: 5, name: 'Boron', weight: 10.811, symbol: 'B',test:"ss"},
  {position: 6, name: 'Carbon', weight: 12.0107, symbol: 'C',test:"ss"},
  {position: 7, name: 'Nitrogen', weight: 14.0067, symbol: 'N',test:"ss"},
  {position: 8, name: 'Oxygen', weight: 15.9994, symbol: 'O',test:"ss"},
  {position: 9, name: 'Fluorine', weight: 18.9984, symbol: 'F',test:"ss"},
  {position: 10, name: 'Neon', weight: 20.1797, symbol: 'Ne',test:"ss"},
];
