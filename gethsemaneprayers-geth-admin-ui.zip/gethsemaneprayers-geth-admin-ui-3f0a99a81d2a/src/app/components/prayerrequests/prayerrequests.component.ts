import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prayerrequests',
  templateUrl: './prayerrequests.component.html',
  styleUrls: ['./prayerrequests.component.scss']
})
export class PrayerrequestsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
