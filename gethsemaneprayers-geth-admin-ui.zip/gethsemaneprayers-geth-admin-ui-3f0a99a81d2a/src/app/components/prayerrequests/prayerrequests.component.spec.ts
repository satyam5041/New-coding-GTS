import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrayerrequestsComponent } from './prayerrequests.component';

describe('PrayerrequestsComponent', () => {
  let component: PrayerrequestsComponent;
  let fixture: ComponentFixture<PrayerrequestsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PrayerrequestsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PrayerrequestsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
