import { Component, OnInit } from '@angular/core';
import { OwlOptions } from 'ngx-owl-carousel-o';

@Component({
  selector: 'app-from-our-blog',
  templateUrl: './from-our-blog.component.html',
  styleUrls: ['./from-our-blog.component.scss']
})
export class FromOurBlogComponent implements OnInit {

  constructor() { }
//img:any='../assets/images/img-liricsChords.jpg';
  ngOnInit(): void {
  }

  fromOurBlog:any={
    blogs:[
      { img:"../assets/images/img-liricsChords.jpg", title:"Small Group Leader Training", description:" Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non... ", postby:"Jane Doe", comments:563
      },
      { img:"../assets/images/img-liricsChords.jpg", title:"Small Group Leader Training", description:" Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non... ", postby:"Jane Doe", comments:563
      },
      {img:"../assets/images/img-liricsChords.jpg", title:"Small Group Leader Training", description:" Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non... ", postby:"Jane Doe", comments:563
      }
    ]
  }




  //export class CarouselHolderComponent {
    customOptions: OwlOptions = {
      loop: true,
      mouseDrag: true,
      touchDrag: true,
      pullDrag: true,
      //dots: true,
      margin:20,
      autoplay:true,
      autoplayTimeout:5000,
      autoplayHoverPause:true,
      //navSpeed: 700,
      //stagePadding: 50,
      
      //navText: ['hi', 'hello'],
      responsive: {
        0: {
          items: 1
        },
        400: {
          items: 2
        },
        1000: {
          items: 3
        },
        1200: {
          items: 4
        }
      },
      //nav: true
    }
  //}
  
}
