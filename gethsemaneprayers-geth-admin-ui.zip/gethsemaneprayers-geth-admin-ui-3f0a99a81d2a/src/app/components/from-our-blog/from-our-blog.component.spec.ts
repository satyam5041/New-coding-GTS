import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FromOurBlogComponent } from './from-our-blog.component';

describe('FromOurBlogComponent', () => {
  let component: FromOurBlogComponent;
  let fixture: ComponentFixture<FromOurBlogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FromOurBlogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FromOurBlogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
