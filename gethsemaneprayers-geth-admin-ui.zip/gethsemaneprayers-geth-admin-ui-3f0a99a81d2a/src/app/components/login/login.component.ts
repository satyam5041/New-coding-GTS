import { Component, OnInit, Output, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
// import * as EventEmitter from 'events';
import { SmallDialogComponent } from 'src/app/feature/small-dialog/small-dialog.component';
import { ApiService } from 'src/app/services/api.service';
import { UserDataService } from 'src/app/services/user-data.service';
import { UserDetailsService } from 'src/app/services/user-details.service';
import { environment } from 'src/environments/environment';
// import { Observable }    from 'rxjs/Observable';

// import {SideNavComponent} from '../../side-nav/side-nav.component';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  // @Output() sendDataToParent = new EventEmitter;

  // @ViewChild(SideNavComponent) sideNav: SideNavComponent;
  formGroup: FormGroup;
  constructor(private formBuilder: FormBuilder, private router: Router, public dialog: MatDialog, private api: ApiService, private userDataService: UserDataService,private userDetailsService:UserDetailsService) { }
  test: any = ' from login component';
  ngOnInit() {
    this.createForm();
  }
  _sendDataToParent(data: string) {
    // this.sendDataToParent.emit(data);
  }

  createForm() {
    this.formGroup = this.formBuilder.group({
      'username': ['siva', Validators.required],
      'password': ['12345678', Validators.required],
    });
  }


  // getError(el:any) {
  //   this.formGroup.get('username')?.hasError('required');
  //   switch (el) {
  //     case 'user':
  //       if (this.formGroup.get('username')?.hasError('required')) {
  //         return 'Username required';
  //       }else{return ''}
  //       break;
  //     case 'pass':
  //       if (this.formGroup.get('password')?.hasError('required')) {
  //         return 'Password required';
  //       }else{return ''}
  //       break;
  //     default:
  //       return '';
  //   }
  // }

  onSubmit() {
    // this.post = post;
    // console.log(this.sideNav)
    // this.sideNav.clickedP();
    // this.userDataService.passValue("from LGIN COM");
    // this.validateUserDetails();
    this.validateUser();
  }
  goTo(r: any) {
    this.router.navigateByUrl(r);
  }

  openDialog(): void {
    let dialogRef = this.dialog.open(SmallDialogComponent, {
      width: '30%',
      data: { title: 'Heading', caption: `caption`, message: 'Hello Meassag', close_btn: 'Close', submit_btn: 'OK' }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed', result);
      // this.animal = result;
    });
  }

  validateUserDetails() {
    // this.router.navigateByUrl('dashboard');
    // return false;
    let url = environment.SERVICE_APIS.validateUserDetails;

    let params = {
      'LOGIN_ID': this.formGroup.value.username,
      'PASSWORD': this.formGroup.value.password
    };

    this.api.POST_AUTH_BR(url, params, true)
      .subscribe(
        response => {
          console.log("USER response:::", response);
          // this.dataList=response;
          // this.dataSource = new MatTableDataSource(response['data']);
          this.setData(response);
        }, err => {
          console.log("ERR::", err)
        }

      );
    // }
  }
  validateUser() {
    // this.router.navigateByUrl('dashboard');
    // return false;
    let url = environment.SERVICE_APIS.validateUser;

    let params = {
      'username': btoa(this.formGroup.value.username),
      'password': btoa(this.formGroup.value.password)
    };

    this.api.POST_AUTH_BR(url, params, true)
      .subscribe(
        response => {
          console.log("USER response:::", response);
          // this.dataList=response;
          // this.dataSource = new MatTableDataSource(response['data']);
          this.setUserData(response);
        }, err => {
          console.log("ERR::", err)
        }

      );
    // }
  }
  setUserData(obj: any) {
    console.log("USERDATA::", obj['data'])
    // this.dataList=obj['recordset'];

    // if (obj['rowsAffected'][0] == 1) {

      // this.userDataService.loginStatus.subscribe(
      //   data => 
      //   {
      //     console.log('next subscribed value side NAVVVV: ' + data);
      //     // this.name = data;
      //   }
      // );

      this.userDataService.setLoginStatus({ loginStatus: true });
      this.userDetailsService.userInfo = obj['data'][0];
      // console.log(this.userDetailsService.userInfo.uniq_id)
// return false;
      this.router.navigateByUrl('dashboard');
    // } else {

    //   this.userDataService.setLoginStatus({ loginStatus: false });
    //   this.userDataService.userDetails.push({});
    // }

    //  const d= this.dataList.filter(((option: { ACTIVE_STATUS: { toLowerCase: () => number[]; }; }) => option.ACTIVE_STATUS.toLowerCase().includes(0)));

    //  console.log("filteD USER LIST",d)
  }
  setData(obj: any) {
    console.log("DATA::", obj['rowsAffected'][0])
    // this.dataList=obj['recordset'];

    if (obj['rowsAffected'][0] == 1) {

      // this.userDataService.loginStatus.subscribe(
      //   data => 
      //   {
      //     console.log('next subscribed value side NAVVVV: ' + data);
      //     // this.name = data;
      //   }
      // );

      this.userDataService.setLoginStatus({ loginStatus: true });
      this.userDataService.userDetails = obj['recordset'][0];

      this.router.navigateByUrl('dashboard');
    } else {

      this.userDataService.setLoginStatus({ loginStatus: false });
      this.userDataService.userDetails.push({});
    }

    //  const d= this.dataList.filter(((option: { ACTIVE_STATUS: { toLowerCase: () => number[]; }; }) => option.ACTIVE_STATUS.toLowerCase().includes(0)));

    //  console.log("filteD USER LIST",d)
  }

}
