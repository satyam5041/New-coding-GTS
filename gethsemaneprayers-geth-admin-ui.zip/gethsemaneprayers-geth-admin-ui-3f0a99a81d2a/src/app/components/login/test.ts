import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {

  title = 'Add Rows';
  list: any = [];
  fname: string = '';
  mname: string = '';
  lname: string = '';
  sal: number = 0;
  constructor() {
    const list: Employee[] = [];
  }
  
  
  addEmp() {
    let emp = {
      fname: this.fname,
      mname: this.mname,
      lname: this.lname,
      sal: this.sal
    }
    this.list.push(emp);
    console.log("Printing Array",this.list);

  }
  
}


export interface Employee {
  fname: string;
  mname: string;
  lname: string;
  sal: number;

}
