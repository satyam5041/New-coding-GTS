import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nextevent',
  templateUrl: './nextevent.component.html',
  styleUrls: ['./nextevent.component.scss']
})
export class NexteventComponent implements OnInit {
  //cnt2 = 0;
  //public data=new Date();
  //public time=new Date().getTime();
   days:number;
   hours:number;
   minutes :number;
   seconds :number;
  constructor() { }

  ngOnInit(): void {
    // this.setIntrvl();
    setInterval(() => this.countDownDate(),1000);
  }
  // startGame2() {
  //   this.cnt2 = this.cnt2 + 1;
  //   console.log ('Count is ' + this.cnt2);
  // }

  // setIntrvl(){
  //   setInterval(() => this.startGame2(),1000);
  // }


   countDownDate() {
    let timeleft = new Date('2021-11-28').getTime() - new Date().getTime();

    let days = Math.floor(timeleft / (1000 * 60 * 60 * 24));
    let hours = Math.floor((timeleft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    let minutes = Math.floor((timeleft % (1000 * 60 * 60)) / (1000 * 60));
    let seconds = Math.floor((timeleft % (1000 * 60)) / 1000);

    this.days=days;
    this.hours=hours;
    this.minutes=minutes;
    this.seconds=seconds;
// days=20;
// console.log(timeleft,"::",timeleft/ (5300 * 60 * 60 * 24),":::",(1000 * 60 * 60 * 24))
    // countdown.innerHTML = output.replace('%d', days).replace('%h', hours).replace('%m', minutes).replace('%s', seconds);
  }
  // countDownDate();
  // setInterval(countDownDate, 1000);
}
