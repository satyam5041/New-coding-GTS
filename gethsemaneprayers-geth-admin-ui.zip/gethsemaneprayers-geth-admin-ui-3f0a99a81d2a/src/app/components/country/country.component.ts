import { Component, OnInit, ViewChild} from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import {MatPaginator} from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import { SmallDialogComponent } from 'src/app/feature/small-dialog/small-dialog.component';
import { ApiService } from 'src/app/services/api.service';
import { ExcelService } from 'src/app/services/excel.service';
import { TooltipPosition } from '@ng-matero/extensions';
import { FormControl } from '@angular/forms';

import {environment} from '../../../environments/environment';
import { CountryDialogComponent } from 'src/app/feature/country-dialog/country-dialog.component';
import { UserDataService } from 'src/app/services/user-data.service';
export interface UserData {
  id: string;
  name: string;
  progress: string;
  fruit: string;
}

@Component({
  selector: 'app-country',
  templateUrl: './country.component.html',
  styleUrls: ['./country.component.scss']
})
export class CountryComponent implements OnInit {

 
 
  displayedColumns: string[] = ['COUNTRY_NAME','CONTINENT','CAPITAL','IDD_CODE','ISO_CODE_2CHAR','ISO_CODE_3CHAR','TIME_ZONE','status','actions'];
  dataSource: MatTableDataSource<UserData>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  dataList:any=[]
  active_status:any="";

  constructor(public dialog: MatDialog,private api:ApiService,private _snackBar: MatSnackBar,private excelService:ExcelService,private userDataService:UserDataService) {
    // Create 100 users
    // const users = Array.from({length: 100}, (_, k) => createNewUser(k + 1));

    // Assign the data to the data source for the table to render
    // this.dataSource = new MatTableDataSource(users);
  }
  positionOptions: TooltipPosition[] = ['after', 'before', 'above', 'below', 'left', 'right'];
  position = new FormControl(this.positionOptions[0]);

 

  ngOnInit(){
    this.getCountries();
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  addCountrylDialog(data:any,editStatus:boolean=false): void {
    console.log("COMP DATA::",data,editStatus)
    let dialogRef = this.dialog.open(CountryDialogComponent, {
      width: '50%',
      data: { title: 'Heading', caption: `caption`,message:'Hello Meassag',close_btn:'Close',submit_btn_1:editStatus?'Update & Close':'Save & Close',submit_btn_2:editStatus?'Update & Add New':'Save & Add New',data:data ,editStatus:editStatus}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed',result);
      this.getCountries();
      // this.animal = result;
    });
  }

  getCountries(){

    let url=environment.SERVICE_APIS.countries;
   
        let params={ACTIVE_STATUS:this.active_status};
        
        this.api.POST_AUTH_BR(url, params, true)
          .subscribe(
            response => {
              console.log("USER response:::", response);
              // this.dataList=response;
              // this.dataSource = new MatTableDataSource(response['data']);
    this.setData(response);
            },err=>{
              console.log("ERR::",err)
            }
    
          );
      // }
      }
      setData(obj:any){
        console.log("DATA::",obj)
        this.dataList=obj['recordset'];
        this.dataSource = new MatTableDataSource(obj['recordset']);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      }

    
      getDataByFilter(e:any){
        console.log("data::",this.active_status);
        // this.active_status
        this.getCountries()
      }

      openSnackBar(message: string, action: string) {
        this._snackBar.open(message, action,{
          duration: 3000,
        });
      }

      deleteCountry(obj:any) {
        // this.post = post;
        console.log()
    
        let url=environment.SERVICE_APIS.deleteCountry;
       
        let CREATED_BY=this.userDataService.userDetails.USER_GUID;
            let params={
              "CREATED_BY":CREATED_BY,
              "COUNTRY_GUID":obj.COUNTRY_GUID,
              "ACTIVE_STATUS":obj.ACTIVE_STATUS
            };
            // console.log("DELE::",params)
            // return false;
            this.api.POST_AUTH_BR(url, params, true)
              .subscribe(
                response => {
                  console.log("DELETE response:::", response);
                  // this.dataList=response;
                  // this.dataSource = new MatTableDataSource(response['data']);
        // this.setData(response);
        // this.onNoClick();
        this.openSnackBar("Deleted success","");
        this.getCountries();
                },err=>{
                  console.log("ERR::",err)
                }
        
              );
    
      }

      deleteCountryDialog(data:any): void {
        let del_status=data.ACTIVE_STATUS?'Active':'Delete';
        let dialogRef = this.dialog.open(SmallDialogComponent, {
          width: '30%',
          data: { title: del_status, caption: ``,message:`Are you sure you want to ${del_status}?`,close_btn:'Close',submit_btn:del_status,data:data,submit_btn_clicked: true}
        });
    
        dialogRef.afterClosed().subscribe(result => {
          console.log('The dialog was closed',result,result.submit_btn_clicked);
if(result.submit_btn_clicked && result.submit_btn_clicked!=undefined){
  this.deleteCountry(result.data);
}
      

          // this.animal = result;
        });
      }
      
      exportAsXLSX():void {
        this.excelService.exportAsExcelFile(this.dataList, 'Countires');
      }


}
