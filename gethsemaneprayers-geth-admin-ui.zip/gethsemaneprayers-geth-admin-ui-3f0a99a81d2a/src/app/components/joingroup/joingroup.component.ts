import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-joingroup',
  templateUrl: './joingroup.component.html',
  styleUrls: ['./joingroup.component.scss']
})
export class JoingroupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
