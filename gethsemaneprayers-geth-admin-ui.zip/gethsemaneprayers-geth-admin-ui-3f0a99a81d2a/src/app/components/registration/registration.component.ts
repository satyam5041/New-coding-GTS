import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import { ApiService } from 'src/app/services/api.service';
import {environment} from '../../../environments/environment';

import {MustMatch} from '../../match.validator';
@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.scss']
})
export class RegistrationComponent implements OnInit {

  isLinear = true;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  name:any='';
  mob:any='';
  username:any='';
  pwd:any='';
  confirm:any='';
  submitted:boolean=false;

  constructor(private formBuilder: FormBuilder,private api:ApiService) {}

  ngOnInit() {
    this.firstFormGroup = this.formBuilder.group({
      name: ['', Validators.required],
      mob: ['', Validators.required],
      username: ['', Validators.required],
    });
    this.secondFormGroup = this.formBuilder.group({
      pwd: ['', Validators.required],
      confirm: ['', Validators.required],
    }, {
      validator: MustMatch('pwd', 'confirm')
  });
  }
  get f() { return this.secondFormGroup.controls; }

  register(){

//     let username=f.value.username.toLowerCase();
//     let name=f.value.name;
//     let pwd=f.value.pwd;
//     let confirm=f.value.confirm;
//     let mob=f.value.mob;
//     let global_cid=f.value.global_cid;
//  console.log("MOB::",mob,mob.toString().length)
//     this.err_msg="";
//     this.err_msg_status=false;
//     if(pwd!=confirm){

//       this.err_msg="Password wrong,please try again.";
//     this.err_msg_status=true;

//     }else if(mob.toString().length<10 && !isNaN(mob)){
//       this.err_msg="Please enter 10 digit mobile no.";
//       this.err_msg_status=true;
//     }else if(isNaN(mob)){
//       this.err_msg="Please enter valid mobile no.";
//       this.err_msg_status=true;
//     }else if(pwd.length<8){
//       this.err_msg="Please enter 8 digit password.";
//       this.err_msg_status=true;
//     }
//     else{

    // let url="http://localhost:80/myapp/ci3/index.php/Api/createUser";
    let url=environment.SERVICE_APIS.createUser;
    // let url="http://localhost:80/myapp/ci3/index.php/Api/validateUser";
    // let url="http://rmeti.com/ci3/index.php/Api/select";
    // if(this.uuid==null){
    //   this.uuid="";
    // }
    let params={"username":btoa('ssss'),"pwd":btoa('ssss'),"confirm":btoa('ssss'),"name":this.name,'mob':90999,"player_id":1212,"uuid":1212,"appname":1212,"global_cid":'1212121'};
    
    this.api.POST_AUTH_BR(url, params, true)
      .subscribe(
        response => {
          console.log("LOGIN response:::", response);
          //console.log(response.roleId);
        //  if(response.sucessCode==200){
          
          // this.UserdetailsService.loginInfo.registrationStatus=true;
          // this.UserdetailsService.loginInfo.regMsg=response.sucessMsg;

          // this.router.navigate(['/login']);

        //  }
      
      

        }

      );
  // }
  }

}
