import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-worshipteam',
  templateUrl: './worshipteam.component.html',
  styleUrls: ['./worshipteam.component.scss']
})
export class WorshipteamComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  worshipteam:any={
    worship:[
      {img:"../assets/images/img-liricsChords.jpg", lyrics:"Lyrics, Chords & Translations", title:"Worship Team Resources", descripation:"We’re passionate about Jesus and leading others to worship Him! We hope these resources help equip you and your team as you lead worship."}
    ]
  }
}
