import { Component, OnInit } from '@angular/core';
import{FormGroup,FormBuilder,Validators} from '@angular/forms';

@Component({
  selector: 'app-forum',
  templateUrl: './forum.component.html',
  styleUrls: ['./forum.component.scss']
})
export class ForumComponent implements OnInit {

  formGroup: FormGroup;
  description:any;
  title:'SUBJECT';
  name:any='';
  

  forumList:any=[
    {title:"SPIRITUAL GROWTH",description:`The Shiba Inu is the smallest of the six original and distinct spitz breeds of dog
    from Japan. A small, agile dog that copes very well with mountainous terrain, the Shiba Inu was
    originally bred for hunting.`},
    {title:"FAMILY UNITENESS",description:`The Shiba Inu is the smallest of the six original and distinct spitz breeds of dog
    from Japan. A small, agile dog that copes very well with mountainous terrain, the Shiba Inu was
    originally bred for hunting.`},
    {title:"MARITAL LIFE",description:`The Shiba Inu is the smallest of the six original and distinct spitz breeds of dog
    from Japan. A small, agile dog that copes very well with mountainous terrain, the Shiba Inu was
    originally bred for hunting.`},
    {title:"HOLY LIFE",description:`The Shiba Inu is the smallest of the six original and distinct spitz breeds of dog
    from Japan. A small, agile dog that copes very well with mountainous terrain, the Shiba Inu was
    originally bred for hunting.`},
    {title:"VICTORIOUS LIFE",description:`The Shiba Inu is the smallest of the six original and distinct spitz breeds of dog
    from Japan. A small, agile dog that copes very well with mountainous terrain, the Shiba Inu was
    originally bred for hunting.`}

  ]
  constructor(private formBuilder: FormBuilder) { }

  ngOnInit(): void {

    this.createForm();
  }

  createForm() {
    this.formGroup = this.formBuilder.group({
      'description': ['', Validators.required],
      name: ['', Validators.required]
    });
  }
  onSubmit() {
  
  }
}
