import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrayerSelfComponent } from './prayer-self.component';

describe('PrayerSelfComponent', () => {
  let component: PrayerSelfComponent;
  let fixture: ComponentFixture<PrayerSelfComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PrayerSelfComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PrayerSelfComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
