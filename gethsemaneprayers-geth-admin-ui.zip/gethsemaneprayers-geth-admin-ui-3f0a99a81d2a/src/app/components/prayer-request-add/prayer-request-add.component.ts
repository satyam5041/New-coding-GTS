import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import { ApiService } from 'src/app/services/api.service';
import {environment} from '../../../environments/environment';

@Component({
  selector: 'app-prayer-request-add',
  templateUrl: './prayer-request-add.component.html',
  styleUrls: ['./prayer-request-add.component.scss']
})
export class PrayerRequestAddComponent implements OnInit {

  isLinear = true;
  submitted:boolean=false;
  show2public:boolean=false;
  name2public:boolean=false;


  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  reason:any='';
  type:any='';
  request:any='';
  name:any='';
  email:any='';
  phone:any='';
  country:any='';
  address:any='';
  

  constructor(private formBuilder: FormBuilder,private api:ApiService) {}
  reasonList: any[] = [
    {
      id: 1,
      text: 'COVID-19',
      selected: false,
      value:"covid19"
      
    },
    {
      id: 2,
      text: 'General',
      selected: false,
      value:"general"
    },
    {
      id: 3,
      text: 'Health',
      selected: false,
      value:"health"
    },
    {
      id: 4,
      text: 'Marriage',
      selected: false,
      value:"marriage"
    }
  ];
  typeList: any[] = [
    {
      id: 1,
      text: 'My Prayer',
      selected: false,
      value:"MY_PRAYER"
      
    },
    {
      id: 2,
      text: 'Co Beleiver',
      selected: false,
      value:"CO_BELIEVER"
    },
    {
      id: 3,
      text: 'Counselling/Appointment',
      selected: false,
      value:"COUSELING_AAP"
    },
    {
      id: 4,
      text: 'Web Prayer',
      selected: false,
      value:"WEB_PRAYER"
    }
  ];
  countryList: any[] = [
    {
      id: 1,
      text: 'India',
      selected: false,
      value:"IN"
      
    },
    {
      id: 2,
      text: 'Afghan',
      selected: false,
      value:"AFG"
    },
    {
      id: 3,
      text: 'US',
      selected: false,
      value:"US"
    },
    {
      id: 4,
      text: 'UK',
      selected: false,
      value:"UK"
    }
  ];
  ngOnInit() {
    this.firstFormGroup = this.formBuilder.group({
      reason: ['', Validators.required],
      type: ['', Validators.required],
      request: ['', Validators.required],
    });
    this.secondFormGroup = this.formBuilder.group({
      name: ['', Validators.required],
      email: ['', Validators.required],
      phone: ['', Validators.required],
      country: ['', Validators.required],
      address: ['', ''],
      show2public: ['', ''],
      name2public: ['', ''],
    }, {
      // validator: MustMatch('pwd', 'confirm')
  });
  }
  get f() { return this.secondFormGroup.controls; }

  register(){

//     let username=f.value.username.toLowerCase();
//     let name=f.value.name;
//     let pwd=f.value.pwd;
//     let confirm=f.value.confirm;
//     let mob=f.value.mob;
//     let global_cid=f.value.global_cid;
//  console.log("MOB::",mob,mob.toString().length)
//     this.err_msg="";
//     this.err_msg_status=false;
//     if(pwd!=confirm){

//       this.err_msg="Password wrong,please try again.";
//     this.err_msg_status=true;

//     }else if(mob.toString().length<10 && !isNaN(mob)){
//       this.err_msg="Please enter 10 digit mobile no.";
//       this.err_msg_status=true;
//     }else if(isNaN(mob)){
//       this.err_msg="Please enter valid mobile no.";
//       this.err_msg_status=true;
//     }else if(pwd.length<8){
//       this.err_msg="Please enter 8 digit password.";
//       this.err_msg_status=true;
//     }
//     else{

    // let url="http://localhost:80/myapp/ci3/index.php/Api/createUser";
    let url=environment.SERVICE_APIS.createUser;
    // let url="http://localhost:80/myapp/ci3/index.php/Api/validateUser";
    // let url="http://rmeti.com/ci3/index.php/Api/select";
    // if(this.uuid==null){
    //   this.uuid="";
    // }
    let params={};
    
    this.api.POST_AUTH_BR(url, params, true)
      .subscribe(
        response => {
          console.log("LOGIN response:::", response);
          //console.log(response.roleId);
        //  if(response.sucessCode==200){
          
          // this.UserdetailsService.loginInfo.registrationStatus=true;
          // this.UserdetailsService.loginInfo.regMsg=response.sucessMsg;

          // this.router.navigate(['/login']);

        //  }
      
      

        }

      );
  // }
  }

}
