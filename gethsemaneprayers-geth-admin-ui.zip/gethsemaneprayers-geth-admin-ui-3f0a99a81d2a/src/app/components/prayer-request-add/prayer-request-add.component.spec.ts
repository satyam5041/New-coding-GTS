import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrayerRequestAddComponent } from './prayer-request-add.component';

describe('PrayerRequestAddComponent', () => {
  let component: PrayerRequestAddComponent;
  let fixture: ComponentFixture<PrayerRequestAddComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PrayerRequestAddComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PrayerRequestAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
