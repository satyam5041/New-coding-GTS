import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PublicPrayersComponent } from './public-prayers.component';

describe('PublicPrayersComponent', () => {
  let component: PublicPrayersComponent;
  let fixture: ComponentFixture<PublicPrayersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PublicPrayersComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PublicPrayersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
