import { Component, OnInit } from '@angular/core';
import{FormGroup,FormBuilder,Validators} from '@angular/forms';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-public-prayers',
  templateUrl: './public-prayers.component.html',
  styleUrls: ['./public-prayers.component.scss']
})
export class PublicPrayersComponent implements OnInit {
  
  
  formGroup: FormGroup;
  publicprayersList:any=[
    {prayertype:"SPIRITUAL GROWTH",description:`The Shiba Inu is the smallest of the six original and distinct spitz breeds of dog
    from Japan. A small, agile dog that copes very well with mountainous terrain, the Shiba Inu was
    originally bred for hunting.`},
    {prayertype:"FAMILY UNITENESS",description:`The Shiba Inu is the smallest of the six original and distinct spitz breeds of dog
    from Japan. A small, agile dog that copes very well with mountainous terrain, the Shiba Inu was
    originally bred for hunting.`},
    {prayertype:"MARITAL LIFE",description:`The Shiba Inu is the smallest of the six original and distinct spitz breeds of dog
    from Japan. A small, agile dog that copes very well with mountainous terrain, the Shiba Inu was
    originally bred for hunting.`},
    {prayertype:"HOLY LIFE",description:`The Shiba Inu is the smallest of the six original and distinct spitz breeds of dog
    from Japan. A small, agile dog that copes very well with mountainous terrain, the Shiba Inu was
    originally bred for hunting.`},
    {prayertype:"VICTORIOUS LIFE",description:`The Shiba Inu is the smallest of the six original and distinct spitz breeds of dog
    from Japan. A small, agile dog that copes very well with mountainous terrain, the Shiba Inu was
    originally bred for hunting.`}

  ]

  constructor(private formBuilder: FormBuilder,private router:Router,private common:CommonService) { }

  ngOnInit(): void {
    this.getProducts();
   }
  
  onSubmit() {
    // this.post = post;
  }
  goTo(r:any,blog:any){
    this.common.selfBlog=blog;
this.router.navigateByUrl(r);
  }
  productList:any;
  getProducts(){
    // this.api.GET_BR_AUTH('http://localhost:8090/api/orders').subscribe(data=>{
    //   console.log("data::",data)
    //   this.productList=data;
    // });
  }

  
}
