import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-carousel',
  templateUrl: './home-carousel.component.html',
  styleUrls: ['./home-carousel.component.scss']
})
export class HomeCarouselComponent implements OnInit {

  banners:any=[
    {img:"../assets/images/banners/banner-1.png", alt:"", title:""},
    {img:"../assets/images/banners/banner-2.png", alt:"", title:""},
    {img:"../assets/images/banners/banner-3.png", alt:"", title:""}
  ];

  constructor() { }

  ngOnInit(): void {
  }

}
