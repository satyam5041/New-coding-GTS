import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-worship',
  templateUrl: './worship.component.html',
  styleUrls: ['./worship.component.scss']
})
export class WorshipComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  worship:any={
    songs:[
      {img:"../assets/images/img-player.jpg", songtitle:"Energy"},
      {img:"", songtitle:"Energy"},
      {img:"", songtitle:"Energy"}
    ]
  }

  upcommingEvents:any={
    events:[
      {month:"May", day:"12", eventname:"Church Leaders meeting", eventtime:"1:00 pm - 7:00 pm"},
      {month:"May", day:"12", eventname:"Church Leaders meeting", eventtime:"1:00 pm - 7:00 pm"},
      {month:"May", day:"12", eventname:"Church Leaders meeting", eventtime:"1:00 pm - 7:00 pm"},
      {month:"May", day:"12", eventname:"Church Leaders meeting", eventtime:"1:00 pm - 7:00 pm"},
      {month:"May", day:"12", eventname:"Church Leaders meeting", eventtime:"1:00 pm - 7:00 pm"}
    ]
  }

}
