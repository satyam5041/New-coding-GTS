import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserDetailsService {

  pageInfo:any={"header_title":"","caption":"","short_form":""};
  loginInfo:any={"registrationStatus":false,"regMsg":"","loginStatus":false};
  dailyPromises:any=[];
  individualPromisesList:any=[];
  promiseTypeList:any=[];
  songLangList:any=[];
  todaySongList:any=[];
  appname="";
  indPromiseImage:any='iVBORw0KGgoAAAANSUhEUgAAACEAAAAdCAYAAAAkXAW5AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAFiUAABYlAUlSJPAAAAULSURBVFhHrZf7T5tVGMf7t+gPM4vxF6EX2gJtaaH3C/e5AcnkMsbiHAlkwW4gLsgkbCiVwXAisMx2CiNcFmDMccfCKhfH2IDN6QjGGOMvxhhjvj7n0LeU8o6sjB8+6fu+7ft9vuc55zzPqUQqk0KlUkGfpIfdYoONsJit/NMadi3A7tlzu9WOVKcLTZ9/isePF18JbiIuLg6aRA2sZksouIOChIIGjbDAwrXL7kRWRgZamj2iwtHATcjkMiiVShhTTDwAMyBkgQVlwbk5umbPGC7KQlFBPjo6rokKRwM3ERsbC7lMBp1WRwEscDmcIRMMbiB4L1xnZmSiuroSfX1dosLREDIhjYmFSqmibKTwubZZt00ICNPEMpOTk4P29muYmr4nKhwN3IRUugWbFpYNZiB8TTDCp8lhc6CosAAjIwNYXg6ICkfDlomgEZaRhPgEmE1mPiUOm31HFgRTJSeL0XylEffvT4mKRsWjhQgTb8fQlChhMBjgdDjgtDt2LEY7ZSA7+wgaGurhnx3Hw4c/iAtHA2lsmwgaYVOiUqtgMpr53AvbkplgBurrP8HgYC838IhGISocBauBKUhY0HAjWztFDoPewNeGsFPycvNQVXUe/QO3EAhMiwpGy+qiH+tDtyBRxCl2mZDFSqHRaGj0ZqSnpSE7KwuVlW50d3uxsOAXFdwPq/du42lTHSSsWoab4DuFPuUKOXQ6HTfwUXUVGfBxAysr86KC+6LlEtYyTZCwESsUiq1aETQgkJ6eFsyAD7O0EEWF9sPCDNa+aceTshP42aSExGg0Il6l5jsjPAtanRZlZaUHPwVLs1gb7sHT8mI8zzbjV4saErbqE6l5hWeBGSgtPY0bN9oPfArWb3fhWa0bG0dt2LQnbplgWzBJl4Q4mhIpLcjUVCc+cJ+F9+sOTB9ASQ5BlXVt8g6eeS5i491MbDq13AA34aQCZOd9wkL1wIzK824MDvVh6cc5cbH9QDVlzT+Gn9qb8PxMfih4yATrAycKC1H78QX4vJ0YGxvmBg6iEAmszk3gSVcnNkpysZmm323CXXEWX7Re4VUwQNVrefkASnEE69/14xdPLf48asEfVtVuEz09N6kRTYq+HA1s8T54EMASrf75+e95VWW6fv845q63Yrm8BH9n6vGXTYXfreodSBapdL5qI2IGWOCJiREMUFn3+TrxVVsrmpo+w8W6GlQXF8JjTsZvNjX+syvxr22bf8iUREyUtdcVMsZGxdr1zMwoRkeHMEQLtr+/G76b1/FlWwuar3pwuaEONTXV+LD6HCoqynGGtvbJk0UoKDiOvLwcZB3JhIUOSi7qzpeSVPAZ1BhMVmPCGI+7KWr00b1ESN3c3CQPNjl1F2Pjw7gz3Ife3m/hpVG1tV1FY+Nl1NZeoCZ2Du+dPoVjue8gNcMFnV4Xqi8v4jDVoNekMsTQyc1MhfG4Wo1yTQJOJcQjR0kmvN4OnjqPpwGVVW6Ulr2PwuJ8pGekwe6g86TNArPFBKMpBckpBugNemi1GsQnqHnLj2yAYsQQbwWNvE68QbxJnfqwVI5DdC0pDqYuN/cYXFSoTBYjH93LiL80cjJCsIwcooIYyc5DTbSQsOhzgeD3MgURt30fyf5NkCATZgHEvt8VeA/DO0xwwfAfs0AvCMLY9ftw9niXnebYOUYgZELGXooYGbveK42RMHG5XL4FHQfYugpHCMr+7bG/nVqNltDif1RL3PStwylPAAAAAElFTkSuQmCC';
  // indPromiseImage:any='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACEAAAAdCAYAAAAkXAW5AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAFiUAABYlAUlSJPAAAAULSURBVFhHrZf7T5tVGMf7t+gPM4vxF6EX2gJtaaH3C/e5AcnkMsbiHAlkwW4gLsgkbCiVwXAisMx2CiNcFmDMccfCKhfH2IDN6QjGGOMvxhhjvj7n0LeU8o6sjB8+6fu+7ft9vuc55zzPqUQqk0KlUkGfpIfdYoONsJit/NMadi3A7tlzu9WOVKcLTZ9/isePF18JbiIuLg6aRA2sZksouIOChIIGjbDAwrXL7kRWRgZamj2iwtHATcjkMiiVShhTTDwAMyBkgQVlwbk5umbPGC7KQlFBPjo6rokKRwM3ERsbC7lMBp1WRwEscDmcIRMMbiB4L1xnZmSiuroSfX1dosLREDIhjYmFSqmibKTwubZZt00ICNPEMpOTk4P29muYmr4nKhwN3IRUugWbFpYNZiB8TTDCp8lhc6CosAAjIwNYXg6ICkfDlomgEZaRhPgEmE1mPiUOm31HFgRTJSeL0XylEffvT4mKRsWjhQgTb8fQlChhMBjgdDjgtDt2LEY7ZSA7+wgaGurhnx3Hw4c/iAtHA2lsmwgaYVOiUqtgMpr53AvbkplgBurrP8HgYC838IhGISocBauBKUhY0HAjWztFDoPewNeGsFPycvNQVXUe/QO3EAhMiwpGy+qiH+tDtyBRxCl2mZDFSqHRaGj0ZqSnpSE7KwuVlW50d3uxsOAXFdwPq/du42lTHSSsWoab4DuFPuUKOXQ6HTfwUXUVGfBxAysr86KC+6LlEtYyTZCwESsUiq1aETQgkJ6eFsyAD7O0EEWF9sPCDNa+aceTshP42aSExGg0Il6l5jsjPAtanRZlZaUHPwVLs1gb7sHT8mI8zzbjV4saErbqE6l5hWeBGSgtPY0bN9oPfArWb3fhWa0bG0dt2LQnbplgWzBJl4Q4mhIpLcjUVCc+cJ+F9+sOTB9ASQ5BlXVt8g6eeS5i491MbDq13AA34aQCZOd9wkL1wIzK824MDvVh6cc5cbH9QDVlzT+Gn9qb8PxMfih4yATrAycKC1H78QX4vJ0YGxvmBg6iEAmszk3gSVcnNkpysZmm323CXXEWX7Re4VUwQNVrefkASnEE69/14xdPLf48asEfVtVuEz09N6kRTYq+HA1s8T54EMASrf75+e95VWW6fv845q63Yrm8BH9n6vGXTYXfreodSBapdL5qI2IGWOCJiREMUFn3+TrxVVsrmpo+w8W6GlQXF8JjTsZvNjX+syvxr22bf8iUREyUtdcVMsZGxdr1zMwoRkeHMEQLtr+/G76b1/FlWwuar3pwuaEONTXV+LD6HCoqynGGtvbJk0UoKDiOvLwcZB3JhIUOSi7qzpeSVPAZ1BhMVmPCGI+7KWr00b1ESN3c3CQPNjl1F2Pjw7gz3Ife3m/hpVG1tV1FY+Nl1NZeoCZ2Du+dPoVjue8gNcMFnV4Xqi8v4jDVoNekMsTQyc1MhfG4Wo1yTQJOJcQjR0kmvN4OnjqPpwGVVW6Ulr2PwuJ8pGekwe6g86TNArPFBKMpBckpBugNemi1GsQnqHnLj2yAYsQQbwWNvE68QbxJnfqwVI5DdC0pDqYuN/cYXFSoTBYjH93LiL80cjJCsIwcooIYyc5DTbSQsOhzgeD3MgURt30fyf5NkCATZgHEvt8VeA/DO0xwwfAfs0AvCMLY9ftw9niXnebYOUYgZELGXooYGbveK42RMHG5XL4FHQfYugpHCMr+7bG/nVqNltDif1RL3PStwylPAAAAAElFTkSuQmCC';
  userInfo:any={};
  familyInfo:any=[];
  goalList:any=[];
  imageBase64:any="";
  player_id:any="";
  uuid:any="";
  weeklyServicesList=[];
  myPrayerList=[];
  myPrayerAnsweredList=[];
  sub_branches=[];
  cartList=[];
  productList=[];
  myPOList=[];
  leadershipTeamList=[];
  testimoniesList=[];
  videosList=[];
  kidzvideosList=[];
  chainPrayerList=[];
  bibleLangs=[];
  chainPrayerTemp={'id':''};
  cartView={"po_no":""};
  bibleThemeDetails={"id":'','theme':"",'sub_title':''};
  forumDetails={"id":'','title':"",'description':'','replies':''};
  examDetails={"id":'','subject':'','type':'','total_ques':0,'user_marks':0,'user_name':''};
  prayerData=new Subject<any>();
  seminarDetails={'id':'','subject':''}
  quizData=[];

  ccc="service";
  // userInfo:any={"id":"35","uniq_id":"111","username":"pesala1","name":"ppp","surname":"pppp","pwd":"siva","mob":"ppp","mail":"kk","addr":"ii","dob":"1982-11-28","gender":"Male","role":"User","avatar":"","marriage_status":"Yes","born_again":"Yes","born_again_date":"2007-08-19","ministry_type":"Ministry","occupation":"aas","other_talents":"aaa","status":"Active","createdby":"0","parent_id":"","relation":"","timestamp":"2019-10-22 17:14:08"};
  constructor() { }

  setPrayerData(msg:any){

    this.prayerData.next({data:msg});
  }

  clearMsg(msg:any){

    this.prayerData.next();
  }
  getPrayerData():Observable<any>{
    return this.prayerData.asObservable();
  }

  filterQuizList(searchTerm:any) {
    // return this.quizData.filter(item => {
    //   return item.subject.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1;
    // });
  }

}
