// import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { BehaviorSubject, throwError, Observable, from } from 'rxjs'
import { map, catchError, mergeMap, switchMap } from 'rxjs/operators';
import { SmallDialogComponent } from '../feature/small-dialog/small-dialog.component';
import { MatDialog } from '@angular/material/dialog';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  // fileTransfer: FileTransferObject;
  access_token: any="";

  error_msg: any;
  errorCheckToken: any;
  url: any;
  dialogRef:any;
  public items: any = [];
  d: Object;
  constructor(
    private _http: HttpClient, 
    public dialog: MatDialog,
   //private _CONSTANTS: ConstantsService, 
    private router: Router,
    // private utilityService: UtilityService
    // private spinnerDialog: SpinnerDialog,
    // private alertCtrl:AlertController,
    // private fileOpener: FileOpener,
    // private transfer: FileTransfer,
    // private file: File

  ) { 
    this.items = [
      { title: "one" },
      { title: "two" },
      { title: "three" },
      { title: "four" },
      { title: "five" },
      { title: "six" }
    ];
  }

  


  POST_AUTH_BR(url:any, params:any, isLoader:boolean) {

    this.url=url;
    if(this.dialogRef!=undefined){
      //console.log("closing popup in service",this.dialogRef);
      // this.dialogRef.close();
      this.closePopup();
    }

    let bearer="";
    let authTxt="";
    let httpHeaders;
    if(this.access_token!="" && this.access_token!=undefined){
      // authTxt="Authorization";
      // bearer='Bearer '+this.access_token;
       httpHeaders = new HttpHeaders()
      // .set("Authorization", 'Bearer '+this.access_token)    
      .set('Content-Type', 'multipart/form-data;')
      // .set('Content-Type', 'application/json; charset=utf-8')
    }else{
      // authTxt='';
      // bearer='';
       httpHeaders = new HttpHeaders()
      .set('Content-Type', 'application/json; charset=utf-8')
    }
    
      

      //console.log("TKN::", this.access_token);
    let options = {
      headers: httpHeaders
    };
    let nreoBj = JSON.stringify(params);
    // let nreoBj = params;

    console.log("REQ PARAMS::", url,params,options,httpHeaders);

    if(isLoader){
      // this.spinnerDialog.show("Ooh!", "please wait...", true);

    }
  
    return this._http.post(url, nreoBj, options).pipe(map(data => {
      // this.spinnerDialog.hide();
      console.log("RESP DATA::",this.url, data);
      // console.log("RESP DATA Data::",this.url, data['data']);
      // console.log("RESP DATA statusCode::",this.url, data['statusCode']);
      // console.log("RESP DATA MSG::",this.url, data['statusMessage']);
      
     return this.setDataResp(data);
// if(data['statusCode']==200){
//   return data['data'];
// }else{

// console.log("EE::",data)
//   //this.errorPopup(data['statusMessage']);
//   return data;
// }
      
     
    }), catchError(err => {
      let errValue;
     
      if(err.error.status==401 ||err.error.status==403 ||err.status==401){
        
        if(err.error.error=="invalid_token"){
          errValue="<b>"+err.error.error+"</b>: Session Expired";

          this.sessionExpired(errValue);
          return throwError(err);
         
        }else{
        errValue="<b>"+err.error.error+"</b>: "+err.error.error_description;
        }
      }
      else if(err.error.status==404){
        errValue="<b>"+err.error.error+"</b>: "+err.error.message;
      }
      else if(err.error.status==500){
        errValue="<b>"+err.headers.status+"</b>: "+err.headers.statusText;
      }else{
        errValue="<b>System Error</b>:Please contact system administrator!";
      }
      
      //this.errorPopup(errValue);
      console.log("EEEE::",errValue,err);
      // this.spinnerDialog.hide();
      this.errorDialog(errValue);
      return throwError(err);
      
    }));
  }
  GET_AUTH_BR(url:any, params:any, isLoader:boolean) {

    this.url=url;
    if(this.dialogRef!=undefined){
      //console.log("closing popup in service",this.dialogRef);
      // this.dialogRef.close();
      this.closePopup();
    }

    let bearer="";
    let authTxt="";
    let httpHeaders;
    if(this.access_token!="" && this.access_token!=undefined){
      // authTxt="Authorization";
      // bearer='Bearer '+this.access_token;
       httpHeaders = new HttpHeaders()
      // .set("Authorization", 'Bearer '+this.access_token)    
      .set('Content-Type', 'multipart/form-data;')
      // .set('Content-Type', 'application/json; charset=utf-8')
    }else{
      // authTxt='';
      // bearer='';
       httpHeaders = new HttpHeaders()
      .set('Content-Type', 'application/json; charset=utf-8')
    }
    
      

      //console.log("TKN::", this.access_token);
    let options = {
      headers: httpHeaders
    };
    // let nreoBj = JSON.stringify(params);
    // let nreoBj = params;

    console.log("REQ PARAMS::", url,params,options,httpHeaders);

    if(isLoader){
      // this.spinnerDialog.show("Ooh!", "please wait...", true);

    }
  // const d:any=[];
    return this._http.get(url, options).pipe(map(data => {
      // this.spinnerDialog.hide();
      console.log("RESP DATA::",this.url, data);
      // console.log("RESP DATA Data::",this.url, data['data']);
      // console.log("RESP DATA statusCode::",this.url, data['statusCode']);
      // console.log("RESP DATA MSG::",this.url, data['statusMessage']);
      // let d={};
      // this.d=data;
     return data;
// if(data['statusCode']==200){
//   return data['data'];
// }else{

// console.log("EE::",data)
//   //this.errorPopup(data['statusMessage']);
//   return data;
// }
      
     
    }), catchError(err => {
      let errValue;
     
      if(err.error.status==401 ||err.error.status==403 ||err.status==401){
        
        if(err.error.error=="invalid_token"){
          errValue="<b>"+err.error.error+"</b>: Session Expired";

          this.sessionExpired(errValue);
          return throwError(err);
         
        }else{
        errValue="<b>"+err.error.error+"</b>: "+err.error.error_description;
        }
      }
      else if(err.error.status==404){
        errValue="<b>"+err.error.error+"</b>: "+err.error.message;
      }
      else if(err.error.status==500){
        errValue="<b>"+err.headers.status+"</b>: "+err.headers.statusText;
      }else{
        errValue="<b>System Error</b>:Please contact system administrator!";
      }
      
      //this.errorPopup(errValue);
      console.log("EEEE::",errValue,err);
      // this.spinnerDialog.hide();
      this.errorDialog(errValue);
      return throwError(err);
      
    }));
  }

  setDataResp(data:any){
    // console.log("setDataResp:::",data);

    if(data['statusCode']==200){
      // console.log("setDataResp data:::",data['data']);
  return data['data'];
}else{

console.log("EE::",data)
  this.errorDialog(data['statusMessage']);
  return data;
}
  }
  async errorAlert(msg:any) {

    // let dd=JSON.stringify(id);
    // console.log("ONE SIGNAL ID:::",id);
    // let playerId=id.userId;
    // const alert = await this.alertCtrl.create({
    //   header: 'Error',
    //   subHeader: 'Exception',
    //   message: msg,
    //   buttons: ['OK']
    // });

    // await alert.present();
  }

  errorPopup(msg:any){
    // this.utilityService.hideLoader();
    if(this.dialogRef!=undefined){
      //console.log("closing popup in service1",this.dialogRef);
      this.dialogRef.close();
    }
        let message = "<p>"+msg+"</p>";
        //  this.dialogRef = this.dialog.open(ModalpopComponent, {
        //   width: '600px', height: '300px', disableClose: true,
        //   data: {
        //     message: message,
        //     button_cancel: "",
        //     button_next: "OK",
        //     button_close: "CLOSE",
        //     button_cancel_disable:true
        //   }
        // });
        this.dialogRef.componentInstance.nextAction.subscribe(()=>{
       //console.log("nextAction");
      //  this.dialogRef .close();
      this.closePopup();
     });
    
     this.dialogRef.componentInstance.popupCloseAction.subscribe(()=>{
       //console.log("Closing... popupCloseAction");
      //  this.dialogRef .close();
      this.closePopup();
     });
     this.dialogRef.componentInstance.cancelOrResndAction.subscribe(()=>{
       //console.log("Closing...cancelOrResndAction");

      //  this.dialogRef.close();
      this.closePopup();
     
       
     });
    
      }
  sessionExpired(msg:any){
    // this.utilityService.hideLoader();
    if(this.dialogRef!=undefined){
      //console.log("closing popup in service1",this.dialogRef);
      this.dialogRef.close();
    }
        let message = "<p>"+msg+"</p>";
        //  this.dialogRef = this.dialog.open(ModalpopComponent, {
        //   width: '600px', height: '300px', disableClose: true,
        //   data: {
        //     message: message,
        //     button_cancel: "",
        //     button_next: "OK",
        //     button_close: "CLOSE",
        //     button_cancel_disable:true
        //   }
        // });
        this.dialogRef.componentInstance.nextAction.subscribe(()=>{
       //console.log("nextAction");
      //  this.dialogRef .close();
      this.closePopup();
      //  this.utilityService.navigate('login');
     });
    
     this.dialogRef.componentInstance.popupCloseAction.subscribe(()=>{
       //console.log("Closing... popupCloseAction");
      //  this.dialogRef .close();
      this.closePopup();
     });
     this.dialogRef.componentInstance.cancelOrResndAction.subscribe(()=>{
       //console.log("Closing...cancelOrResndAction");
    
      //  this.dialogRef.close();
      this.closePopup();
     
       
     });
    
      }

  closePopup(){
    this.dialogRef.close();
    // this.utilityService.hideLoader();
  }

  download(url: string, title: string) {
    // this.fileTransfer = this.transfer.create();
    // console.log("PATH::",this.fileTransfer,url)
    // this.fileTransfer
    //   .download(url, this.file.dataDirectory + title + ".pdf")
    //   .then(entry => {
    //     console.log("download complete: " + entry.toURL());
    //     this.fileOpener
    //       .open(entry.toURL(), "application/pdf")
    //       .then(() => console.log("File is opened"))
    //       .catch(e => console.log("Error opening file", e));
    //   });
  }
  filterItems(searchTerm:any) {
    // return this.items.filter(item => {
    //   return item.title.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1;
    // });
  }
  errorDialog(msg:any): void {
    let dialogRef = this.dialog.open(SmallDialogComponent, {
      width: '30%',
      data: { title: 'Error', caption: ``,message:msg,close_btn:'',submit_btn:'OK',submit_btn_clicked: true}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed',result);
// if(result.submit_btn_clicked && result.submit_btn_clicked!=undefined){
// // this.deleteCompany(result.data);
// }
  

      // this.animal = result;
    });
  }
  GET(url:any){
    return this._http.get(url);
  }

  GET_BR_AUTH(url:string){

    return this._http.get(url);
  }

 
}
