import { DatePipe } from '@angular/common';
import { Component, OnInit,Inject } from '@angular/core';
import { FormBuilder,FormGroup, FormControl, Validators} from '@angular/forms';

import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Observable } from 'rxjs';
import { ApiService } from 'src/app/services/api.service';
import {environment} from '../../../environments/environment';
import {MustMatch} from '../../match.validator';
// import { saveAs } from 'file-saver';

import {map, startWith} from 'rxjs/operators';
import { UserDataService } from 'src/app/services/user-data.service';
@Component({
  selector: 'app-user-dialog',
  templateUrl: './user-dialog.component.html',
  styleUrls: ['./user-dialog.component.scss']
})
export class UserDialogComponent implements OnInit {

  formGroup: FormGroup;
  deptFormControl = new FormControl();
  myControl = new FormControl();
  myControld = new FormControl();

  userList: any[] = this.data.userList;
  userFilteredData:any=[];
  companyList: any[] = this.data.companyList;
  companyFilteredData:any=[];
  base64File: string = '';
  filename: string = '';
  // deptOptions: any[] = [
  //   {id:1,dept_name:"IT"},
  //   {id:2,dept_name:"NETWORK"},
  //   {id:3,dept_name:"SECURITY"},
  // ];
  options: string[] = ['One', 'Two', 'Three'];
  filteredOptions: Observable<string[]>;

  optionsc: string[] = ['One', 'Two', 'Three','Four'];
  filteredOptionsc: Observable<string[]>;

  optionsd: any[] = [{"id":"1","name":"Dept-1"},{"id":"2","name":"Dept-2"},{"id":"2","name":"Dept-3"}];
  filteredOptionsd: Observable<any[]>;

  userIDstatus:number=0;
  hide_pass = true;
  hide_pass_cnf = true;
  constructor(
    public dialogRef: MatDialogRef<UserDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,private formBuilder: FormBuilder,private api:ApiService,private datePipe: DatePipe,private userDataService:UserDataService) { 
      dialogRef.disableClose = true;
      this.createForm();
      this.dataURLtoFile('data:text/plain;base64,aGVsbG8gd29ybGQ=','hello.txt');
    }

  onNoClick(): void {
    this.dialogRef.close();
  }

  ngOnInit(): void {
    console.log("ddddddd::",this.data);
    // this.createForm();

    this.filteredOptions = this.myControl.valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value)),
    );

    this.filteredOptionsc = this.deptFormControl.valueChanges.pipe(
      startWith(''),
      map(value => this._filter_cust(value)),
    );
    this.filteredOptionsd = this.myControld.valueChanges.pipe(
      startWith(''),
      map(value => this._filterd(value)),
    );
    console.log("===filteredOptions==::",this.filteredOptions);
    this.userFilteredData = this.formGroup.get('MANAGER_GUID')?.valueChanges.pipe(
      startWith(''),
      map(value => this.setfilteredUserOptions(value)),
    );
    this.companyFilteredData = this.formGroup.get('COMPANY_GUID')?.valueChanges.pipe(
      startWith(''),
      map(value => this.setfilteredComapnyOptions(value)),
    );
  }
  createForm() {
    this.formGroup = this.formBuilder.group({
      'LOGIN_ID': [this.data.data.LOGIN_ID, Validators.required],
      'USER_FIRST_NAME': [this.data.data.USER_FIRST_NAME, Validators.required],
      'USER_MIDDLE_NAME': [this.data.data.USER_MIDDLE_NAME, ''],
      'USER_LAST_NAME': [this.data.data.USER_LAST_NAME, Validators.required],
      'DOB': [this.datePipe.transform(this.data.data.DOB,'yyyy-MM-dd'), Validators.required],
      'PASSWORD': [this.data.data.PASSWORD, Validators.required],
      'cnf_pwd': ['', Validators.required],
      'USER_DESIGNATION': [this.data.data.USER_DESIGNATION, ''],
      'DEPARTMENT_GUID': [this.data.data.DEPARTMENT_GUID, ''],
      'COMPANY_GUID': new FormControl(this.data.data.COMPANY_GUID, []),
      'MANAGER_GUID': new FormControl(this.data.data.MANAGER_GUID, []),
      'DATE_OF_JOINING': [this.datePipe.transform(this.data.data.DATE_OF_JOINING,'yyyy-MM-dd'), ''],
      'DATE_OF_PROBATION': [this.datePipe.transform(this.data.data.DATE_OF_PROBATION,'yyyy-MM-dd'), ''],
      'DATE_OF_CONFIRMATION': [this.datePipe.transform(this.data.data.DATE_OF_CONFIRMATION,'yyyy-MM-dd'), ''],
      'DATE_OF_TERMINATION': [this.datePipe.transform(this.data.data.DATE_OF_TERMINATION,'yyyy-MM-dd'), ''],
      'PRESENT_ADDRESS': [this.data.data.PRESENT_ADDRESS, ''],
      'PERMANENT_ADDRESS': [this.data.data.PERMANENT_ADDRESS, ],
      'EMAIL_ID': [this.data.data.EMAIL_ID, Validators.email],
      'PHONE_NUMBER': [this.data.data.PHONE_NUMBER,  Validators.minLength(10)],
      'PROFILE_PICTURE': [this.data.data.PROFILE_PICTURE,  ''],
      'filename': ['',  ''],
    }, {
      validator: MustMatch('PASSWORD', 'cnf_pwd')
  });
  }
  get f() { return this.formGroup.controls; }
  // getError(el:any) {
  //   this.formGroup.get('username')?.hasError('required');
  //   switch (el) {
  //     case 'user':
  //       if (this.formGroup.get('username')?.hasError('required')) {
  //         return 'Username required';
  //       }else{return ''}
  //       break;
  //     case 'pass':
  //       if (this.formGroup.get('password')?.hasError('required')) {
  //         return 'Password required';
  //       }else{return ''}
  //       break;
  //     default:
  //       return '';
  //   }
  // }
  popupCloseAction:boolean=false;
  onSubmit(popupCloseAction:boolean=false) {
    // this.post = post;
    console.log()
this.popupCloseAction=popupCloseAction;
    let url=environment.SERVICE_APIS.addUser;
    if(this.data.editStatus){
      url=environment.SERVICE_APIS.updateUser;
    }
    let CREATED_BY=this.userDataService.userDetails.USER_GUID;
    
        let params={
          'LOGIN_ID':this.formGroup.value.LOGIN_ID,
          'USER_FIRST_NAME':this.formGroup.value.USER_FIRST_NAME,
          'USER_MIDDLE_NAME':this.formGroup.value.USER_MIDDLE_NAME,
          'USER_LAST_NAME':this.formGroup.value.USER_LAST_NAME,
          'DOB':this.formGroup.value.DOB,
          'PASSWORD':this.formGroup.value.PASSWORD,
          'USER_DESIGNATION':this.formGroup.value.USER_DESIGNATION,
          'DEPARTMENT_GUID':this.formGroup.value.DEPARTMENT_GUID,
          'COMPANY_GUID':this.formGroup.value.COMPANY_GUID,
          'MANAGER_GUID':this.formGroup.value.MANAGER_GUID,
          'DATE_OF_JOINING':this.formGroup.value.DATE_OF_JOINING,
          'DATE_OF_PROBATION':this.formGroup.value.DATE_OF_PROBATION,
          'DATE_OF_CONFIRMATION':this.formGroup.value.DATE_OF_CONFIRMATION,
          'DATE_OF_TERMINATION':this.formGroup.value.DATE_OF_TERMINATION,
          'PRESENT_ADDRESS':this.formGroup.value.PRESENT_ADDRESS,
          'PERMANENT_ADDRESS':this.formGroup.value.PERMANENT_ADDRESS,
          'EMAIL_ID':this.formGroup.value.EMAIL_ID,
          'PHONE_NUMBER':this.formGroup.value.PHONE_NUMBER,
          'PROFILE_PICTURE':this.base64File,
          "CREATED_BY":CREATED_BY,
          "USER_GUID":this.data.data.USER_GUID,
        };
        
        console.log("USER PARAMS::",params);
        // return false;
        this.api.POST_AUTH_BR(url, params, true)
          .subscribe(
            response => {
              console.log("companies response:::",this.popupCloseAction, response);
              // this.dataList=response;
              // this.dataSource = new MatTableDataSource(response['data']);
    // this.setData(response);
    if(!this.popupCloseAction){
      this.dialogRef.disableClose = true;
      this.onNoClick();
    }else{
      
      this.onReset();
    }
    
            },err=>{
              console.log("ERR::",err)
            }
    
          );

  }

  onReset() {
    // this.submitted = false;
    this.formGroup.reset();
}
checkUserIDAvailability(){
  this.userIDstatus=0;
  console.log("",this.formGroup.value.LOGIN_ID);

  let url=environment.SERVICE_APIS.checkUserIDAvailability;

  let CREATED_BY=this.userDataService.userDetails.USER_GUID;
    
        let params={
          'LOGIN_ID':this.formGroup.value.LOGIN_ID
        };
        
        console.log("USER PARAMS::",params);
        // return false;
        this.api.POST_AUTH_BR(url, params, true)
          .subscribe(
            response => {
              console.log("avail resp:::", response.recordset[0].count);
              // this.dataList=response;
              // this.dataSource = new MatTableDataSource(response['data']);
    // this.setData(response);
 this.userIDstatus=response.recordset[0].count;
    
            },err=>{
              console.log("ERR::",err)
            }
    
          );
}
private _filter(value: string): string[] {
  const filterValue = value.toLowerCase();

  return this.options.filter(option => option.toLowerCase().includes(filterValue));
}
private _filter_cust(value: string): string[] {
  const filterValue = value.toLowerCase();
console.log("option logs::",this.optionsc);

  return this.optionsc.filter(option =>option.toLowerCase().includes(filterValue));
}

private _filterd(value: string): string[] {
  const filterValue = value.toLowerCase();
console.log(this.optionsd);
  return this.optionsd.filter(option => option.name.toLowerCase().includes(filterValue));
}



  onFileSelect(e: any): void {
    try {
      const file = e.target.files[0];
      const fReader = new FileReader()
      fReader.readAsDataURL(file)
      fReader.onloadend = (_event: any) => {
        this.filename = file.name;
        this.base64File = _event.target.result;
        // console.log("FILE::",this.base64File);
      }
    } catch (error) {
      this.filename = '';
      this.base64File = '';
      console.log('no file was selected...');
    }
  }

  private setfilteredUserOptions(value: string): string[] {
    const filterValue = value.toLowerCase();
  console.log("filter user list:::",this.userList);
  // this.countryList.filter(option=>);
    return this.userList.filter((option => option.LOGIN_ID.toLowerCase().includes(filterValue)));
  }
  private setfilteredComapnyOptions(value: string): string[] {
    const filterValue = value.toLowerCase();
  console.log("filter company list:::",this.userList);
  // this.countryList.filter(option=>);
    return this.companyList.filter((option => option.COMPANY_NAME.toLowerCase().includes(filterValue)));
  }

   dataURLtoFile(dataurl:any, filename:any) {
    const blob = 
        new Blob([
                 "Please Save Me!"], 
                 {type: "text/plain;charset=utf-8"});
    // saveAs(blob, "./save-me.txt");

    return false;
 console.log("creating file.....")
    var arr = dataurl.split(','),
        mime = arr[0].match(/:(.*?);/)[1],
        bstr = atob(arr[1]), 
        n = bstr.length, 
        u8arr = new Uint8Array(n);
        
    while(n--){
        u8arr[n] = bstr.charCodeAt(n);
    }
    
    return new File([u8arr], filename, {type:mime});
}

}
