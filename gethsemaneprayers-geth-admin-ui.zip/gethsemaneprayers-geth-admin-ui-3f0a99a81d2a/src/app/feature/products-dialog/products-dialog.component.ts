import { DatePipe } from '@angular/common';
import { Component, OnInit,Inject } from '@angular/core';
import { FormBuilder,FormGroup, FormControl, Validators} from '@angular/forms';

import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Observable } from 'rxjs';
import { ApiService } from 'src/app/services/api.service';
import {environment} from '../../../environments/environment';
import {MustMatch} from '../../match.validator';

import {map, startWith} from 'rxjs/operators';
import { UserDetailsService } from 'src/app/services/user-details.service';
@Component({
  selector: 'app-products-dialog',
  templateUrl: './products-dialog.component.html',
  styleUrls: ['./products-dialog.component.scss']
})
export class ProductsDialogComponent implements OnInit {

  formGroup: FormGroup;
  promiseTypeList: any[] = this.data.promiseTypeList;

  
  promiseTypeFilteredData:any=[];

  userIDstatus:number=0;
  hide_pass = true;
  hide_pass_cnf = true;
  base64File: string = '';
  filename: string = '';
  fileProps:any=[];
  constructor(
    public dialogRef: MatDialogRef<ProductsDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,private formBuilder: FormBuilder,private api:ApiService,private datePipe: DatePipe,private userDetailsService:UserDetailsService) { 
      dialogRef.disableClose = true;
    }


    productsList = [
      {
        id: '',
        name: '--Select--'
      },
      {
        id: '1',
        name: '1'
      },
      {
        id: '2',
        name: '2'
      },
      {
        id: '3',
        name: '3'
      },
      {
        id: '4',
        name: '4'
      },
      
    ];

    categoryList = [
      {
        id: '',
        name: '--Select--'
      },
      {
        id: '1',
        name: '1'
      },
      {
        id: '2',
        name: '2'
      },
      {
        id: '3',
        name: '3'
      },
      {
        id: '4',
        name: '4'
      },
      
    ];
    subcategoryList = [
      {
        id: '',
        name: '--Select--'
      },
      {
        id: '1',
        name: '1'
      },
      {
        id: '2',
        name: '2'
      },
      {
        id: '3',
        name: '3'
      },
      {
        id: '4',
        name: '4'
      },
      
    ];

    currencyList = [
      {
        id: '',
        name: '--Select--'
      },
      {
        id: 'INR',
        name: 'INR'
      }
      
    ];

    currencySymbolList = [
      {
        id: '',
        name: '--Select--'
      },
      {
        id: '#8377;',
        name: '#8377;'
      }
     
    ];

    offerList = [
      {
        id: '',
        name: '--Select--'
      },
      {
        id: 'PERCENT',
        name: 'percent'
      },
      {
        id: 'PRICE',
        name: 'price'
      },
      {
        id: 'NO',
        name: 'no'
      } 
    ];


  onNoClick(): void {
    this.dialogRef.close();
  }

  ngOnInit(): void {
    console.log("ddddddd::",this.data);
    this.createForm();

   
  
    this.promiseTypeFilteredData = this.formGroup.get('promise_type')?.valueChanges.pipe(
      startWith(''),
      map(value => this.setfilteredPromiseTypeOptions(value)),
    );
  }
  
  createForm() {
    this.formGroup = this.formBuilder.group({
      'product_name': [this.data.data.product_name, Validators.required],
      'product_code': [this.data.data.product_code, Validators.required],
      'auth_manufacturer': [this.data.data.auth_manufacturer, Validators.required],
      'type': [this.data.data.type, Validators.required],
      'category_id': [this.data.data.category_id, Validators.required],
      'sub_category_id': [this.data.data.sub_category_id, Validators.required],
      'currency': [this.data.data.currency, Validators.required],
      'offer_applicable': [this.data.data.offer_applicable, Validators.required],
      'original_price': [this.data.data.original_price, Validators.required],
      'selling_price': [this.data.data.selling_price, Validators.required],
      'final_price': [this.data.data.final_price, Validators.required],
      'offer_percent_disc': [this.data.data.offer_percent_disc, Validators.required],
      'offer_price_disc': [this.data.data.offer_price_disc, Validators.required],
      'description': [this.data.data.description, Validators.required],
      'specifications': [this.data.data.specifications, ''],
      'currency_symbol': [this.data.data.currency_symbol, ''],
      'file': [this.data.data.file, ''],
      'file_path': ["", ""],
      'filename': ['',  ''],
    });
  }
  get f() { return this.formGroup.controls; }
 
  popupCloseAction:boolean=false;
  onSubmit(popupCloseAction:boolean=false) {
    // this.post = post;
    console.log()
this.popupCloseAction=popupCloseAction;
    let url=environment.SERVICE_APIS.addProduct;
    if(this.data.editStatus){
      url=environment.SERVICE_APIS.updateProduct;
    }
    let uniq_id=this.userDetailsService.userInfo.uniq_id;
    let global_cid=this.userDetailsService.userInfo.global_cid;
    
        let params={
          'product_name':this.formGroup.value.product_name,
          'product_code':this.formGroup.value.product_code,
          'auth_manufacturer':this.formGroup.value.auth_manufacturer,
          'type':this.formGroup.value.type,
          'category_id':this.formGroup.value.category_id,
          'sub_category_id':this.formGroup.value.sub_category_id,
          'currency':this.formGroup.value.currency,
          'offer_applicable':this.formGroup.value.offer_applicable,
          'original_price':this.formGroup.value.original_price,
          'selling_price':this.formGroup.value.selling_price,
          'offer_percent_disc':this.formGroup.value.offer_percent_disc,
          'offer_price_disc':this.formGroup.value.offer_price_disc,
          'final_price':this.formGroup.value.final_price,
          'description':this.formGroup.value.description,
          'specifications':this.formGroup.value.specifications,
          'currency_symbol':'&#8377',
          'file':this.formGroup.value.file,
          'global_cid':global_cid,
          "uniq_id":uniq_id,
          "id":this.data.data.id,
        };
        
        console.log("USER PARAMS::",params);
        // return false;
        this.api.POST_AUTH_BR(url, params, true)
          .subscribe(
            response => {
              console.log("companies response:::",this.popupCloseAction, response);
    // this.setData(response);
    if(!this.popupCloseAction){
      this.dialogRef.disableClose = true;
      this.onNoClick();
    }else{
      
      this.onReset();
    }
    
            },err=>{
              console.log("ERR::",err)
            }
    
          );

  }

  onReset() {
    // this.submitted = false;
    this.formGroup.reset();
}


private setfilteredPromiseTypeOptions(value: string): string[] {
 
 
  const filterValue = value.toLowerCase();
// console.log("filter company list:::",this.userList);
// this.countryList.filter(option=>);
  return this.promiseTypeList.filter((option => option.promise_type.toLowerCase().includes(filterValue)));

}



  onFileSelect(e: any): void {
    try {
      const file = e.target.files[0];
      const fReader = new FileReader()
      fReader.readAsDataURL(file)
      fReader.onloadend = (_event: any) => {
        this.filename = file.name;
        this.base64File = _event.target.result;
        console.log("filename::",this.filename);
        console.log("file pros::",file);
        this.fileProps=file;
        // console.log("FILE base64::",this.base64File);
      }
    } catch (error) {
      this.filename = '';
      this.base64File = '';
      console.log('no file was selected...');
    }
  }


}