import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChainprayerDialogComponent } from './chainprayer-dialog.component';

describe('ChainprayerDialogComponent', () => {
  let component: ChainprayerDialogComponent;
  let fixture: ComponentFixture<ChainprayerDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChainprayerDialogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChainprayerDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
