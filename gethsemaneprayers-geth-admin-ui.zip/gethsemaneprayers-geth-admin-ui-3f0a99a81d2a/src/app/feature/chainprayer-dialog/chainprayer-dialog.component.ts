import { DatePipe } from '@angular/common';
import { Component, OnInit,Inject } from '@angular/core';
import { FormBuilder,FormGroup, FormControl, Validators} from '@angular/forms';

import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Observable } from 'rxjs';
import { ApiService } from 'src/app/services/api.service';
import {environment} from '../../../environments/environment';
import {MustMatch} from '../../match.validator';

import {map, startWith} from 'rxjs/operators';
import { UserDetailsService } from 'src/app/services/user-details.service';

@Component({
  selector: 'app-chainprayer-dialog',
  templateUrl: './chainprayer-dialog.component.html',
  styleUrls: ['./chainprayer-dialog.component.scss']
})
export class ChainprayerDialogComponent implements OnInit {

 
  formGroup: FormGroup;
  promiseTypeList: any[] = this.data.promiseTypeList;

  
  promiseTypeFilteredData:any=[];

  userIDstatus:number=0;
  hide_pass = true;
  hide_pass_cnf = true;
  base64File: string = '';
  filename: string = '';
  fileProps:any=[];
  constructor(
    public dialogRef: MatDialogRef<ChainprayerDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,private formBuilder: FormBuilder,private api:ApiService,private datePipe: DatePipe,private userDetailsService:UserDetailsService) { 
      dialogRef.disableClose = true;
    }


    starttimeList = [
      {
        id: '',
        name: '--Select--',
      },
      {
        id: '00:00:00',
        name: '00:00',
      },
      {
        id: '01:00:00',
        name: '01:00',
      },
      {
        id: '02:00:00',
        name: '02:00',
      },
      {
        id: '03:00:00',
        name: '03:00',
      },
      {
        id: '04:00:00',
        name: '04:00',
      },
      {
        id: '05:00:00',
        name: '05:00',
      },
      {
        id: '06:00:00',
        name: '06:00',
      },
      {
        id: '07:00:00',
        name: '07:00',
      },
      {
        id: '08:00:00',
        name: '08:00',
      },
      {
        id: '09:00:00',
        name: '09:00',
      },
      {
        id: '10:00:00',
        name: '10:00',
      },
      {
        id: '11:00:00',
        name: '11:00',
      },
      {
        id: '12:00:00',
        name: '12:00',
      },
      {
        id: '13:00:00',
        name: '13:00',
      },
      {
        id: '14:00:00',
        name: '14:00',
      },
      {
        id: '15:00:00',
        name: '1:00',
      },
      {
        id: '16:00:00',
        name: '16:00',
      },
      {
        id: '17:00:00',
        name: '17:00',
      },
      {
        id: '18:00:00',
        name: '18:00',
      },
      {
        id: '19:00:00',
        name: '19:00',
      },
      {
        id: '20:00:00',
        name: '20:00',
      },
      {
        id: '21:00:00',
        name: '21:00',
      },
      {
        id: '22:00:00',
        name: '22:00',
      },
      {
        id: '23:00:00',
        name: '23:00',
      },
      
    ];

    timelimitList = [
      {
        id: '',
        name: '--Select--',
      },
      {
        id: 15,
        name: '15 mins',
      },
      {
        id: 30,
        name: '30 mins',
      },
      {
        id:45,
        name: '45 mins',
      },
      {
        id: 60,
        name: '1 hour',
      },
      {
        id: 75,
        name: '1 hour 15 mins',
      },
      {
        id: 90,
        name: '1 hour 30 mins',
      },
      {
        id: 105,
        name: '1 hour 45 mins',
      },
      {
        id: 120,
        name: '2 hour',
      },
    ];
  onNoClick(): void {
    this.dialogRef.close();
  }

  ngOnInit(): void {
    console.log("ddddddd::",this.data);
    this.createForm();

   
  
    this.promiseTypeFilteredData = this.formGroup.get('promise_type')?.valueChanges.pipe(
      startWith(''),
      map(value => this.setfilteredPromiseTypeOptions(value)),
    );
  }
  
  createForm() {
    this.formGroup = this.formBuilder.group({
      'time_limit': [this.data.data.time_limit, Validators.required],
      'start_time': [this.data.data.start_time, ''],
      'start_date': [this.data.data.start_date, Validators.required],
      'hours': [this.data.data.hours, Validators.required],
      'subject': [this.data.data.subject, Validators.required],
      'file_path': ["", ""],
      'filename': ['',  ''],
    });
  }
  get f() { return this.formGroup.controls; }

  popupCloseAction:boolean=false;
  onSubmit(popupCloseAction:boolean=false) {
    // this.post = post;
    console.log()
this.popupCloseAction=popupCloseAction;
    let url=environment.SERVICE_APIS.addChainPrayer;
    if(this.data.editStatus){
      url=environment.SERVICE_APIS.updateChainPrayer;
    }
    let uniq_id=this.userDetailsService.userInfo.uniq_id;
    let global_cid=this.userDetailsService.userInfo.global_cid;
    
        let params={
          'start_date':this.formGroup.value.start_date,
          'start_time':this.formGroup.value.start_time,
          'time_limit':this.formGroup.value.time_limit,
          'hours':this.formGroup.value.hours,
          'subject':this.formGroup.value.subject,
          //'type':'ADMIN',
          'global_cid':global_cid,
          "uniq_id":uniq_id,
         "id":this.data.data.id,
        };
        
        console.log("USER PARAMS::",params);
        // return false;
        this.api.POST_AUTH_BR(url, params, true)
          .subscribe(
            response => {
              console.log("companies response:::",this.popupCloseAction, response);
              // this.dataList=response;
              // this.dataSource = new MatTableDataSource(response['data']);
    // this.setData(response);
    if(!this.popupCloseAction){
      this.dialogRef.disableClose = true;
      this.onNoClick();
    }else{
      
      this.onReset();
    }
    
            },err=>{
              console.log("ERR::",err)
            }
    
          );

  }

  onReset() {
    // this.submitted = false;
    this.formGroup.reset();
}


private setfilteredPromiseTypeOptions(value: string): string[] {
 
 
  const filterValue = value.toLowerCase();
// console.log("filter company list:::",this.userList);
// this.countryList.filter(option=>);
  return this.promiseTypeList.filter((option => option.promise_type.toLowerCase().includes(filterValue)));

}



  onFileSelect(e: any): void {
    try {
      const file = e.target.files[0];
      const fReader = new FileReader()
      fReader.readAsDataURL(file)
      fReader.onloadend = (_event: any) => {
        this.filename = file.name;
        this.base64File = _event.target.result;
        console.log("filename::",this.filename);
        console.log("file pros::",file);
        this.fileProps=file;
        // console.log("FILE base64::",this.base64File);
      }
    } catch (error) {
      this.filename = '';
      this.base64File = '';
      console.log('no file was selected...');
    }
  }


}

