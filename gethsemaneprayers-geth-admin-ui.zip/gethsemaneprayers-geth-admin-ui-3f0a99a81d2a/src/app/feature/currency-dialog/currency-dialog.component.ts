import { DatePipe } from '@angular/common';
import { Component, OnInit,Inject } from '@angular/core';
import { FormBuilder,FormGroup, FormControl, Validators} from '@angular/forms';

import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Observable } from 'rxjs';
import { ApiService } from 'src/app/services/api.service';
import {environment} from '../../../environments/environment';
import {MustMatch} from '../../match.validator';

import {map, startWith} from 'rxjs/operators';
import { UserDataService } from 'src/app/services/user-data.service';

@Component({
  selector: 'app-currency-dialog',
  templateUrl: './currency-dialog.component.html',
  styleUrls: ['./currency-dialog.component.scss']
})
export class CurrencyDialogComponent implements OnInit {

  formGroup: FormGroup;
  deptFormControl = new FormControl();
  myControl = new FormControl();
  myControld = new FormControl();
  // COUNTRY_ID = new FormControl(this.data.data.COUNTRY_ID,[]);

  // formGroup= new FormGroup({
  //   COUNTRY_ID: new FormControl('sss', [Validators.required]),
  //   SHORT_CODE: new FormControl(),
  //   DESCRIPTION: new FormControl(),
  //   Called_As: new FormControl(),
  //   filename: new FormControl(),
  // })

  
  // deptOptions: any[] = [
  //   {id:1,dept_name:"IT"},
  //   {id:2,dept_name:"NETWORK"},
  //   {id:3,dept_name:"SECURITY"},
  // ];
  options: string[] = ['One', 'Two', 'Three'];
  filteredOptions: Observable<string[]>;

  optionsc: string[] = ['One', 'Two', 'Three','Four'];
  filteredOptionsc: Observable<string[]>;

  optionsd: any[] = [{"id":"1","name":"Dept-1"},{"id":"2","name":"Dept-2"},{"id":"2","name":"Dept-3"}];
  
  countryList: any[] = this.data.countryList;
  filteredOptionsd: Observable<any[]>;
  filteredCuntryOptions: Observable<any[]>;
  l: Observable<any[]>;
ld:any=[];
  userIDstatus:number=0;
  hide_pass = true;
  hide_pass_cnf = true;
  constructor(
    public dialogRef: MatDialogRef<CurrencyDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,private formBuilder: FormBuilder,private api:ApiService,private datePipe: DatePipe,private userDataService:UserDataService) { 
      dialogRef.disableClose = true;
      // this.getCountries();
    }

  onNoClick(): void {
    this.dialogRef.close();
  }

  ngOnInit(): void {
    console.log("ddddddd::",this.data);
    this.createForm();

    this.filteredOptions = this.myControl.valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value)),
    );

    this.filteredOptionsc = this.deptFormControl.valueChanges.pipe(
      startWith(''),
      map(value => this._filter_cust(value)),
    );
    this.filteredOptionsd = this.myControld.valueChanges.pipe(
      startWith(''),
      map(value => this._filterd(value)),
    );

    // this.l=this.formGroup.get('SHORT_CODE')?.valueChanges.pipe(startWith(''),map(value=>this.setfilteredCuntryOptions(value)));

    // this.l = this.COUNTRY_ID.valueChanges.pipe(
    //   startWith(''),
    //   map(value => this.setfilteredCuntryOptions(value)),
    // );
    this.ld = this.formGroup.get('COUNTRY_ID')?.valueChanges.pipe(
      startWith(''),
      map(value => this.setfilteredCuntryOptions(value)),
    );

    this.formGroup.get('SHORT_CODE')
    // this.reactiveForm.get("address").valueChanges.subscribe(selectedValue => {
    //   console.log('address changed')
    //   console.log(selectedValue)
    // })
    console.log("===filteredOptions==::",this.filteredOptions);
   
  }
  createForm() {
    this.formGroup = this.formBuilder.group({
      'COUNTRY_ID': new FormControl(this.data.data.COUNTRY_ID, [Validators.required]),
      'SHORT_CODE': [this.data.data.SHORT_CODE, ''],
      'DESCRIPTION': [this.data.data.DESCRIPTION, ''],
      'Called_As': [this.data.data.Called_As, Validators.required],
      'filename': ['',  ''],
    
    });
  }
  get f() { return this.formGroup.controls; }
  // getError(el:any) {
  //   this.formGroup.get('username')?.hasError('required');
  //   switch (el) {
  //     case 'user':
  //       if (this.formGroup.get('username')?.hasError('required')) {
  //         return 'Username required';
  //       }else{return ''}
  //       break;
  //     case 'pass':
  //       if (this.formGroup.get('password')?.hasError('required')) {
  //         return 'Password required';
  //       }else{return ''}
  //       break;
  //     default:
  //       return '';
  //   }
  // }
  popupCloseAction:boolean=false;
  onSubmit(popupCloseAction:boolean=false) {
    // this.post = post;
    console.log("c id::",this.formGroup.value.COUNTRY_ID);
    // return false;
this.popupCloseAction=popupCloseAction;
    let url=environment.SERVICE_APIS.addCurrency;
    if(this.data.editStatus){
      url=environment.SERVICE_APIS.updateCurrency;
    }
    let CREATED_BY=this.userDataService.userDetails.USER_GUID;
    
        let params={
          'COUNTRY_ID':this.formGroup.value.COUNTRY_ID,
          'SHORT_CODE':this.formGroup.value.SHORT_CODE,
          'DESCRIPTION':this.formGroup.value.DESCRIPTION,
          'Called_As':this.formGroup.value.Called_As,
          "CREATED_BY":CREATED_BY,
          "CURRENCY_GUID":this.data.data.CURRENCY_GUID,
        };
        
        console.log("USER PARAMS::",params);
        // return false;
        this.api.POST_AUTH_BR(url, params, true)
          .subscribe(
            response => {
              console.log("companies response:::",this.popupCloseAction, response);
              // this.dataList=response;
              // this.dataSource = new MatTableDataSource(response['data']);
    // this.setData(response);
    if(!this.popupCloseAction){
      this.dialogRef.disableClose = true;
      this.onNoClick();
    }else{
      
      this.onReset();
    }
    
            },err=>{
              console.log("ERR::",err)
            }
    
          );

  }

  onReset() {
    // this.submitted = false;
    this.formGroup.reset();
}

private _filter(value: string): string[] {
  const filterValue = value.toLowerCase();

  return this.options.filter(option => option.toLowerCase().includes(filterValue));
}
private _filter_cust(value: string): string[] {
  const filterValue = value.toLowerCase();
console.log("option logs::",this.optionsc);

  return this.optionsc.filter(option =>option.toLowerCase().includes(filterValue));
}

private _filterd(value: string): string[] {
  const filterValue = value.toLowerCase();
console.log(this.optionsd);
  return this.optionsd.filter(option => option.name.toLowerCase().includes(filterValue));
}

private setfilteredCuntryOptions(value: string): string[] {
  const filterValue = value.toLowerCase();
console.log("filter coutry list:::",this.countryList);
  return this.countryList.filter((option => option.COUNTRY_NAME.toLowerCase().includes(filterValue)));
}



base64File: string = '';
  filename: string = '';

  onFileSelect(e: any): void {
    try {
      const file = e.target.files[0];
      const fReader = new FileReader()
      fReader.readAsDataURL(file)
      fReader.onloadend = (_event: any) => {
        this.filename = file.name;
        this.base64File = _event.target.result;
        // console.log("FILE::",this.base64File);
      }
    } catch (error) {
      this.filename = '';
      this.base64File = '';
      console.log('no file was selected...');
    }
  }

}
