import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MyPromiseDialogComponent } from './my-promise-dialog.component';

describe('MyPromiseDialogComponent', () => {
  let component: MyPromiseDialogComponent;
  let fixture: ComponentFixture<MyPromiseDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MyPromiseDialogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MyPromiseDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
