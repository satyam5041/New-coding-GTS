import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChurchDialogComponent } from './church-dialog.component';

describe('ChurchDialogComponent', () => {
  let component: ChurchDialogComponent;
  let fixture: ComponentFixture<ChurchDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChurchDialogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChurchDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
