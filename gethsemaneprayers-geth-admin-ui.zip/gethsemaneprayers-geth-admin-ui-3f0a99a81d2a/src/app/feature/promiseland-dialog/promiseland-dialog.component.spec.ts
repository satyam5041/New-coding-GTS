import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PromiselandDialogComponent } from './promiseland-dialog.component';

describe('PromiselandDialogComponent', () => {
  let component: PromiselandDialogComponent;
  let fixture: ComponentFixture<PromiselandDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PromiselandDialogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PromiselandDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
