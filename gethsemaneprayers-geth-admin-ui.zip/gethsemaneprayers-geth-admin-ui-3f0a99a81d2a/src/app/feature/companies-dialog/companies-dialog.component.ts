import { DatePipe } from '@angular/common';
import { Component, OnInit,Inject } from '@angular/core';
import { FormBuilder,FormGroup, FormControl, Validators} from '@angular/forms';

import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Observable } from 'rxjs';
import { ApiService } from 'src/app/services/api.service';
import {environment} from '../../../environments/environment';
import {MustMatch} from '../../match.validator';

import {map, startWith} from 'rxjs/operators';
import { UserDataService } from 'src/app/services/user-data.service';

@Component({
  selector: 'app-companies-dialog',
  templateUrl: './companies-dialog.component.html',
  styleUrls: ['./companies-dialog.component.scss']
})
export class CompaniesDialogComponent implements OnInit {
  formGroup: FormGroup;
  countryList: any[] = this.data.countryList;
  countryFilteredData:any=[];
  currencyList: any[] = this.data.currencyList;
  currencyFilteredData:any=[];
  constructor(
    public dialogRef: MatDialogRef<CompaniesDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,private formBuilder: FormBuilder,private api:ApiService,private datePipe: DatePipe,private userDataService:UserDataService) { 
      dialogRef.disableClose = true;

    this.createForm();
    }

  onNoClick(): void {
    this.dialogRef.close();
  }

  ngOnInit(): void {
    console.log("ddddddd::",this.formGroup.get('OFF_COUNTRY'));
    // this.getCountries();
    this.countryFilteredData = this.formGroup.get('OFF_COUNTRY')?.valueChanges.pipe(
      startWith(''),
      map(value => this.setfilteredCuntryOptions(value)),
    );
    this.currencyFilteredData = this.formGroup.get('BASE_CURRENCY')?.valueChanges.pipe(
      startWith(''),
      map(value => this.setfilteredCurrencyOptions(value)),
    );

  }
  createForm() {
    this.formGroup = this.formBuilder.group({
      'COMPANY_NAME': [this.data.data.COMPANY_NAME, Validators.required],
      'SHORT_NAME': [this.data.data.SHORT_NAME, ''],
      'COMPANY_TYPE': [this.data.data.COMPANY_TYPE, ''],
      'REGISTRATION_NUM': [this.data.data.REGISTRATION_NUM, ''],
      'INCORPORATED_ON': [this.datePipe.transform(this.data.data.INCORPORATED_ON,'yyyy-MM-dd'), ''],
      'BASE_CURRENCY': new FormControl(this.data.data.BASE_CURRENCY, []),
      'OFF_ADDRESS': [this.data.data.OFF_ADDRESS, ''],
      'OFF_CITY': [this.data.data.OFF_CITY, ''],
      'OFF_COUNTRY': new FormControl(this.data.data.OFF_COUNTRY, [Validators.required]),
      'OFF_ZIP': [this.data.data.OFF_ZIP,  Validators.minLength(6)],
      'OFF_EMAIL_1': [this.data.data.OFF_EMAIL_1, Validators.email],
      'OFF_EMAIL_2': [this.data.data.OFF_EMAIL_2, Validators.email],
      'OFF_PHONE_1': [this.data.data.OFF_PHONE_1,  Validators.minLength(10)],
      'OFF_PHONE_2': [this.data.data.OFF_PHONE_2,  Validators.minLength(10)],
      'OFF_FAX_1': [this.data.data.OFF_FAX_1, ''],
      'OFF_FAX_2': [this.data.data.OFF_FAX_2, '']
    });
  }
  get f() { return this.formGroup.controls; }
  // getError(el:any) {
  //   this.formGroup.get('username')?.hasError('required');
  //   switch (el) {
  //     case 'user':
  //       if (this.formGroup.get('username')?.hasError('required')) {
  //         return 'Username required';
  //       }else{return ''}
  //       break;
  //     case 'pass':
  //       if (this.formGroup.get('password')?.hasError('required')) {
  //         return 'Password required';
  //       }else{return ''}
  //       break;
  //     default:
  //       return '';
  //   }
  // }
  popupCloseAction:boolean=false;
  onSubmit(popupCloseAction:boolean=false) {
    // this.post = post;
    console.log()
this.popupCloseAction=popupCloseAction;
    let url=environment.SERVICE_APIS.addCompany;
    if(this.data.editStatus){
      url=environment.SERVICE_APIS.updateCompany;
    }
    let CREATED_BY=this.userDataService.userDetails.USER_GUID;
        let params={
          'COMPANY_NAME':this.formGroup.value.COMPANY_NAME,
          'SHORT_NAME':this.formGroup.value.SHORT_NAME,
          'COMPANY_TYPE':this.formGroup.value.COMPANY_TYPE,
          'REGISTRATION_NUM':this.formGroup.value.REGISTRATION_NUM,
          'INCORPORATED_ON':this.formGroup.value.INCORPORATED_ON,
          'BASE_CURRENCY':this.formGroup.value.BASE_CURRENCY,
          'OFF_ADDRESS':this.formGroup.value.OFF_ADDRESS,
          'OFF_CITY':this.formGroup.value.OFF_CITY,
          'OFF_COUNTRY':this.formGroup.value.OFF_COUNTRY,
          'OFF_ZIP':this.formGroup.value.OFF_ZIP,
          'OFF_EMAIL_1':this.formGroup.value.OFF_EMAIL_1,
          'OFF_EMAIL_2':this.formGroup.value.OFF_EMAIL_2,
          'OFF_PHONE_1':this.formGroup.value.OFF_PHONE_1,
          'OFF_PHONE_2':this.formGroup.value.OFF_PHONE_2,
          'OFF_FAX_1':this.formGroup.value.OFF_FAX_1,
          'OFF_FAX_2':this.formGroup.value.OFF_FAX_2,
          "CREATED_BY":CREATED_BY,
          "COMPANY_GUID":this.data.data.COMPANY_GUID
        };
        
        this.api.POST_AUTH_BR(url, params, true)
          .subscribe(
            response => {
              console.log("companies response:::",this.popupCloseAction, response);
              // this.dataList=response;
              // this.dataSource = new MatTableDataSource(response['data']);
    // this.setData(response);
    if(!this.popupCloseAction){
      this.dialogRef.disableClose = true;
      this.onNoClick();
    }else{
      
      this.onReset();
    }
    
            },err=>{
              console.log("ERR::",err)
            }
    
          );

  }

  onReset() {
    // this.submitted = false;
    this.formGroup.reset();
}

// getCountries(){
//   let url=environment.SERVICE_APIS.getCountries;

//   this.api.GET(url).subscribe(
//     response => {
//       console.log("countries response:::", response);
//       // this.dataList=response;
//       // this.dataSource = new MatTableDataSource(response['data']);
// // this.setData(response);

// this.setCountryData(response);
//     },err=>{
//       console.log("ERR::",err)
//     }

//   );
// }
// setCountryData(d:any){

//   console.log("COUNTEIRS::",d.data);
//   this.countryList=d.data;
// }

private setfilteredCuntryOptions(value: string): string[] {
  const filterValue = value.toLowerCase();
console.log("filter coutry list:::",this.countryList);
// this.countryList.filter(option=>);
  return this.countryList.filter((option => option.COUNTRY_NAME.toLowerCase().includes(filterValue)));
}
private setfilteredCurrencyOptions(value: string): string[] {
  const filterValue = value.toLowerCase();
console.log("filter coutry list:::",this.countryList);
// this.countryList.filter(option=>);
  return this.currencyList.filter((option => option.COUNTRY_ID.toLowerCase().includes(filterValue)));
}
}
