import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MatrimonyDialogComponent } from './matrimony-dialog.component';

describe('MatrimonyDialogComponent', () => {
  let component: MatrimonyDialogComponent;
  let fixture: ComponentFixture<MatrimonyDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MatrimonyDialogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MatrimonyDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
