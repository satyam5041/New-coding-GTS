import { DatePipe } from '@angular/common';
import { Component, OnInit,Inject } from '@angular/core';
import { FormBuilder,FormGroup, FormControl, Validators} from '@angular/forms';

import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Observable } from 'rxjs';
import { ApiService } from 'src/app/services/api.service';
import {environment} from '../../../environments/environment';
import {MustMatch} from '../../match.validator';

import {map, startWith} from 'rxjs/operators';
import { UserDetailsService } from 'src/app/services/user-details.service';
@Component({
  selector: 'app-matrimony-dialog',
  templateUrl: './matrimony-dialog.component.html',
  styleUrls: ['./matrimony-dialog.component.scss']
})
export class MatrimonyDialogComponent implements OnInit {

  formGroup: FormGroup;
  promiseTypeList: any[] = this.data.promiseTypeList;

  
  promiseTypeFilteredData:any=[];

  userIDstatus:number=0;
  hide_pass = true;
  hide_pass_cnf = true;
  base64File: string = '';
  filename: string = '';
  fileProps:any=[];
  constructor(
    public dialogRef: MatDialogRef<MatrimonyDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,private formBuilder: FormBuilder,private api:ApiService,private datePipe: DatePipe,private userDetailsService:UserDetailsService) { 
      dialogRef.disableClose = true;
    }


    genderList = [
      {
        id: '',
        name: '--Select--'
      },
      {
        id: 'MALE',
        name: 'Male'
      },
      {
        id: 'FEMALE',
        name: 'Female'
      }
      
    ];

    maritalList = [
      {
        id: '',
        name: '--Select--'
      },
      {
        id: 'NEVER_MARRIED',
        name: 'NEVER_MARRIED'
      },
      {
        id: 'MARRIED',
        name: 'MARRIED'
      },
      {
        id: 'AWAITING_DIVORCE',
        name: 'AWAITING_DIVORCE'
      },
      {
        id: 'DIVORCED',
        name: 'DIVORCED'
      },
      {
        id: 'WIDOWED',
        name: 'WIDOWED'
      },
      {
        id: 'ANNULLED',
        name: 'ANNULLED'
      }
      
    ];
    mothertoungeList = [
      {
        id: '',
        name: '--Select--'
      },
      {
        id: 'HINDI/DELHI',
        name: 'HINDI'
      },
      {
        id: 'PUNJABI',
        name: 'PUNJABI'
      },
      {
        id: 'HARYANVI',
        name: 'HARYANVI'
      },
      {
        id: 'URDU',
        name: 'URDU'
      },
      
    ];

    religionList = [
      {
        id: '',
        name: '--Select--'
      },
      {
        id: 'CHRISTIAN',
        name: 'CHRISTIAN'
      }
      
    ];

    countryList = [
      {
        id: '',
        name: '--Select--'
      },
      {
        id: 'INDIA',
        name: 'INDIA'
      }
      
    ];
    statusList = [
      {
        id: '',
        name: '--Select--'
      },
      {
        id: 'OPEN',
        name: 'OPEN'
      },
      {
        id: 'CLOSED',
        name: 'CLOSED'
      },
      {
        id: 'WORK IN PROGRESS',
        name: 'WORK IN PROGRESS'
      },
      
    ];

  onNoClick(): void {
    this.dialogRef.close();
  }

  ngOnInit(): void {
    console.log("ddddddd::",this.data);
    this.createForm();

   
  
    this.promiseTypeFilteredData = this.formGroup.get('promise_type')?.valueChanges.pipe(
      startWith(''),
      map(value => this.setfilteredPromiseTypeOptions(value)),
    );
  }
  
  createForm() {
    this.formGroup = this.formBuilder.group({
      'name': [this.data.data.name, Validators.required],
      'mob': [this.data.data.mob, Validators.required],
      'gender': [this.data.data.gender, Validators.required],
      'dob': [this.data.data.dob, Validators.required],
      'height': [this.data.data.height, Validators.required],
      'qualification': [this.data.data.qualification, Validators.required],
      'marital_status': [this.data.data.marital_status, Validators.required],
      'mother_tounge': [this.data.data.mother_tounge, Validators.required],
      'religion': [this.data.data.religion, Validators.required],
      'caste': [this.data.data.caste, Validators.required],
      'addr': [this.data.data.addr, Validators.required],
      'city': [this.data.data.city, Validators.required],
      'country': [this.data.data.country, Validators.required],
      //'file': [this.data.data.file, Validators.required],
      //'status': [this.data.data.status, Validators.required],
      'reqs': [this.data.data.reqs, Validators.required],
      'other_info': [this.data.data.other_info,''],
      'file_path': ["", ""],
      'filename': ['',  ''],
    });
  }
  get f() { return this.formGroup.controls; }
 
  popupCloseAction:boolean=false;
  onSubmit(popupCloseAction:boolean=false) {
    // this.post = post;
    console.log()
this.popupCloseAction=popupCloseAction;
    let url=environment.SERVICE_APIS.addMatrimony;
    if(this.data.editStatus){
      url=environment.SERVICE_APIS.updateMatrimony;
    }
    let uniq_id=this.userDetailsService.userInfo.uniq_id;
    let global_cid=this.userDetailsService.userInfo.global_cid;
    
        let params={
          'name':this.formGroup.value.name,
          'mob':this.formGroup.value.mob,
          'gender':this.formGroup.value.gender,
          'dob':this.formGroup.value.dob,
          'height':this.formGroup.value.height,
          'qualification':this.formGroup.value.qualification,
          'marital_status':this.formGroup.value.marital_status,
          'mother_tounge':this.formGroup.value.mother_tounge,
          'religion':this.formGroup.value.religion,
          'caste':this.formGroup.value.caste,
          'addr':this.formGroup.value.addr,
          'city':this.formGroup.value.city,
          'country':this.formGroup.value.country,
         // 'file':this.formGroup.value.file,
          //'status':this.formGroup.value.status,
          'reqs':this.formGroup.value.reqs,
          'other_info':this.formGroup.value.other_info,
          'global_cid':global_cid,
          "uniq_id":uniq_id,
          "id":this.data.data.id,
        };
        
        console.log("USER PARAMS::",params);
        // return false;
        this.api.POST_AUTH_BR(url, params, true)
          .subscribe(
            response => {
              console.log("companies response:::",this.popupCloseAction, response);
    // this.setData(response);
    if(!this.popupCloseAction){
      this.dialogRef.disableClose = true;
      this.onNoClick();
    }else{
      
      this.onReset();
    }
    
            },err=>{
              console.log("ERR::",err)
            }
    
          );

  }

  onReset() {
    // this.submitted = false;
    this.formGroup.reset();
}


private setfilteredPromiseTypeOptions(value: string): string[] {
 
 
  const filterValue = value.toLowerCase();
// console.log("filter company list:::",this.userList);
// this.countryList.filter(option=>);
  return this.promiseTypeList.filter((option => option.promise_type.toLowerCase().includes(filterValue)));

}



  onFileSelect(e: any): void {
    try {
      const file = e.target.files[0];
      const fReader = new FileReader()
      fReader.readAsDataURL(file)
      fReader.onloadend = (_event: any) => {
        this.filename = file.name;
        this.base64File = _event.target.result;
        console.log("filename::",this.filename);
        console.log("file pros::",file);
        this.fileProps=file;
        // console.log("FILE base64::",this.base64File);
      }
    } catch (error) {
      this.filename = '';
      this.base64File = '';
      console.log('no file was selected...');
    }
  }


}