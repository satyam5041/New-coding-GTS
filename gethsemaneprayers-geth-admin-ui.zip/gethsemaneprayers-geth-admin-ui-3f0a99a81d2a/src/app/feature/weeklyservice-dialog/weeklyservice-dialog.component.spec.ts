import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WeeklyserviceDialogComponent } from './weeklyservice-dialog.component';

describe('WeeklyserviceDialogComponent', () => {
  let component: WeeklyserviceDialogComponent;
  let fixture: ComponentFixture<WeeklyserviceDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WeeklyserviceDialogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WeeklyserviceDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
