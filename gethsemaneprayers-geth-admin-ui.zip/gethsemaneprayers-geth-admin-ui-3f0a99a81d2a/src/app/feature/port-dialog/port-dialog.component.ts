import { DatePipe } from '@angular/common';
import { Component, OnInit,Inject } from '@angular/core';
import { FormBuilder,FormGroup, FormControl, Validators} from '@angular/forms';

import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Observable } from 'rxjs';
import { ApiService } from 'src/app/services/api.service';
import {environment} from '../../../environments/environment';
import {MustMatch} from '../../match.validator';

import {map, startWith} from 'rxjs/operators';
import { UserDataService } from 'src/app/services/user-data.service';
@Component({
  selector: 'app-port-dialog',
  templateUrl: './port-dialog.component.html',
  styleUrls: ['./port-dialog.component.scss']
})
export class PortDialogComponent implements OnInit {

  
 
  formGroup: FormGroup;
  deptFormControl = new FormControl();
  myControl = new FormControl();
  myControld = new FormControl();

  countryList: any[] = this.data.countryList;
  countryFilteredData:any=[];

  // deptOptions: any[] = [
  //   {id:1,dept_name:"IT"},
  //   {id:2,dept_name:"NETWORK"},
  //   {id:3,dept_name:"SECURITY"},
  // ];
  options: string[] = ['One', 'Two', 'Three'];
  filteredOptions: Observable<string[]>;

  optionsc: string[] = ['One', 'Two', 'Three','Four'];
  filteredOptionsc: Observable<string[]>;

  optionsd: any[] = [{"id":"1","name":"Dept-1"},{"id":"2","name":"Dept-2"},{"id":"2","name":"Dept-3"}];
  filteredOptionsd: Observable<any[]>;

  userIDstatus:number=0;
  hide_pass = true;
  hide_pass_cnf = true;
  constructor(
    public dialogRef: MatDialogRef<PortDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,private formBuilder: FormBuilder,private api:ApiService,private datePipe: DatePipe,private userDataService:UserDataService) { 
      dialogRef.disableClose = true;
      this.createForm();
    }

  onNoClick(): void {
    this.dialogRef.close();
  }

  ngOnInit(): void {
    console.log("ddddddd::",this.data);
   

    this.filteredOptions = this.myControl.valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value)),
    );

    this.filteredOptionsc = this.deptFormControl.valueChanges.pipe(
      startWith(''),
      map(value => this._filter_cust(value)),
    );
    this.filteredOptionsd = this.myControld.valueChanges.pipe(
      startWith(''),
      map(value => this._filterd(value)),
    );
    console.log("===filteredOptions==::",this.filteredOptions);
    this.countryFilteredData = this.formGroup.get('Country_GUID')?.valueChanges.pipe(
      startWith(''),
      map(value => this.setfilteredCuntryOptions(value)),
    );
  }
  createForm() {
    this.formGroup = this.formBuilder.group({
      'Port_Name': [this.data.data.Port_Name, Validators.required],
      'World_port_index_number': [this.data.data.World_port_index_number, Validators.required],
      'Country_GUID': [this.data.data.Country_GUID, ''],
      'Latitude_degrees': [this.data.data.Latitude_degrees, Validators.required],
      'Latitude_minutes': [this.data.data.Latitude_minutes,''],
      'Latitude_seconds': [this.data.data.Latitude_seconds, Validators.required],
      'Latitude_hemisphere': [this.data.data.Latitude_hemisphere, ''],
      'Longitude_degrees': [this.data.data.Longitude_degrees, ''],
      'Longitude_minutes': [this.data.data.Longitude_minutes, ''],
      'Longitude_seconds': [this.data.data.Longitude_seconds,  ''],
      'Longitude_hemisphere': [this.data.data.Longitude_hemisphere,  ''],
      'filename': ['',  ''],
    });
  }
  get f() { return this.formGroup.controls; }
  // getError(el:any) {
  //   this.formGroup.get('username')?.hasError('required');
  //   switch (el) {
  //     case 'user':
  //       if (this.formGroup.get('username')?.hasError('required')) {
  //         return 'Username required';
  //       }else{return ''}
  //       break;
  //     case 'pass':
  //       if (this.formGroup.get('password')?.hasError('required')) {
  //         return 'Password required';
  //       }else{return ''}
  //       break;
  //     default:
  //       return '';
  //   }
  // }
  popupCloseAction:boolean=false;
  onSubmit(popupCloseAction:boolean=false) {
    // this.post = post;
    console.log()
this.popupCloseAction=popupCloseAction;
    let url=environment.SERVICE_APIS.addPort;
    if(this.data.editStatus){
      url=environment.SERVICE_APIS.updatePort;
    }
    let CREATED_BY=this.userDataService.userDetails.USER_GUID;
    
        let params={
          'Port_Name':this.formGroup.value.Port_Name,
          'World_port_index_number':this.formGroup.value.World_port_index_number,
          'Country_GUID':this.formGroup.value.Country_GUID,
          'Latitude_degrees':this.formGroup.value.Latitude_degrees,
          'Latitude_minutes':this.formGroup.value.Latitude_minutes,
          'Latitude_seconds':this.formGroup.value.Latitude_seconds,
          'Latitude_hemisphere':this.formGroup.value.Latitude_hemisphere,
          'Longitude_degrees':this.formGroup.value.Longitude_degrees,
          'Longitude_minutes':this.formGroup.value.Longitude_minutes,
          'Longitude_seconds':this.formGroup.value.Longitude_seconds,
          'Longitude_hemisphere':this.formGroup.value.Longitude_hemisphere,
          "CREATED_BY":CREATED_BY,
          "PORT_GUID":this.data.data.PORT_GUID,
        };
        
        console.log("USER PARAMS::",params);
        // return false;
        this.api.POST_AUTH_BR(url, params, true)
          .subscribe(
            response => {
              console.log("companies response:::",this.popupCloseAction, response);
              // this.dataList=response;
              // this.dataSource = new MatTableDataSource(response['data']);
    // this.setData(response);
    if(!this.popupCloseAction){
      this.dialogRef.disableClose = true;
      this.onNoClick();
    }else{
      
      this.onReset();
    }
    
            },err=>{
              console.log("ERR::",err)
            }
    
          );

  }

  onReset() {
    // this.submitted = false;
    this.formGroup.reset();
}
checkUserIDAvailability(){
  this.userIDstatus=0;
  console.log("",this.formGroup.value.LOGIN_ID);

  let url=environment.SERVICE_APIS.checkUserIDAvailability;

  let CREATED_BY=this.userDataService.userDetails.USER_GUID;
    
        let params={
          'LOGIN_ID':this.formGroup.value.LOGIN_ID
        };
        
        console.log("USER PARAMS::",params);
        // return false;
        this.api.POST_AUTH_BR(url, params, true)
          .subscribe(
            response => {
              console.log("avail resp:::", response.recordset[0].count);
              // this.dataList=response;
              // this.dataSource = new MatTableDataSource(response['data']);
    // this.setData(response);
 this.userIDstatus=response.recordset[0].count;
    
            },err=>{
              console.log("ERR::",err)
            }
    
          );
}
private _filter(value: string): string[] {
  const filterValue = value.toLowerCase();

  return this.options.filter(option => option.toLowerCase().includes(filterValue));
}
private _filter_cust(value: string): string[] {
  const filterValue = value.toLowerCase();
console.log("option logs::",this.optionsc);

  return this.optionsc.filter(option =>option.toLowerCase().includes(filterValue));
}

private _filterd(value: string): string[] {
  const filterValue = value.toLowerCase();
console.log(this.optionsd);
  return this.optionsd.filter(option => option.name.toLowerCase().includes(filterValue));
}

base64File: string = '';
  filename: string = '';

  onFileSelect(e: any): void {
    try {
      const file = e.target.files[0];
      const fReader = new FileReader()
      fReader.readAsDataURL(file)
      fReader.onloadend = (_event: any) => {
        this.filename = file.name;
        this.base64File = _event.target.result;
        // console.log("FILE::",this.base64File);
      }
    } catch (error) {
      this.filename = '';
      this.base64File = '';
      console.log('no file was selected...');
    }
  }

  private setfilteredCuntryOptions(value: string): string[] {
    const filterValue = value.toLowerCase();
  console.log("filter coutry list:::",this.countryList);
  // this.countryList.filter(option=>);
    return this.countryList.filter((option => option.COUNTRY_NAME.toLowerCase().includes(filterValue)));
  }

}
