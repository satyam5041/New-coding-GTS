import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LeadershipDialogComponent } from './leadership-dialog.component';

describe('LeadershipDialogComponent', () => {
  let component: LeadershipDialogComponent;
  let fixture: ComponentFixture<LeadershipDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LeadershipDialogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LeadershipDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
