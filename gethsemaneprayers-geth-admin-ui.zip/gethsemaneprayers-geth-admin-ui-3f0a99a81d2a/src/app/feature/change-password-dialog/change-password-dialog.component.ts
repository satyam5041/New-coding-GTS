import { DatePipe } from '@angular/common';
import { Component, OnInit,Inject } from '@angular/core';
import { FormBuilder,FormGroup, FormControl, Validators} from '@angular/forms';

import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Observable } from 'rxjs';
import { ApiService } from 'src/app/services/api.service';
import { UserDataService } from 'src/app/services/user-data.service';
import {environment} from '../../../environments/environment';
import {MustMatch} from '../../match.validator';

@Component({
  selector: 'app-change-password-dialog',
  templateUrl: './change-password-dialog.component.html',
  styleUrls: ['./change-password-dialog.component.scss']
})
export class ChangePasswordDialogComponent implements OnInit {

  formGroup: FormGroup;
  deptFormControl = new FormControl();
  myControl = new FormControl();
  myControld = new FormControl();

  userList: any[] = this.data.userList;
  userFilteredData:any=[];
  companyList: any[] = this.data.companyList;
  companyFilteredData:any=[];
  // deptOptions: any[] = [
  //   {id:1,dept_name:"IT"},
  //   {id:2,dept_name:"NETWORK"},
  //   {id:3,dept_name:"SECURITY"},
  // ];
  options: string[] = ['One', 'Two', 'Three'];
  filteredOptions: Observable<string[]>;

  optionsc: string[] = ['One', 'Two', 'Three','Four'];
  filteredOptionsc: Observable<string[]>;

  optionsd: any[] = [{"id":"1","name":"Dept-1"},{"id":"2","name":"Dept-2"},{"id":"2","name":"Dept-3"}];
  filteredOptionsd: Observable<any[]>;

  userIDstatus:number=0;
  hide_pass = true;
  hide_pass_cnf = true;
  hide_pass_new = true;
  constructor(
    public dialogRef: MatDialogRef<ChangePasswordDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,private formBuilder: FormBuilder,private api:ApiService,private datePipe: DatePipe,private userDataService:UserDataService) { 
      dialogRef.disableClose = true;
      this.createForm();
      this.dataURLtoFile('data:text/plain;base64,aGVsbG8gd29ybGQ=','hello.txt');
    }

  onNoClick(): void {
    this.dialogRef.close();
  }

  ngOnInit(): void {
    

  }
  createForm() {
    this.formGroup = this.formBuilder.group({
      'PASSWORD': ['', Validators.required],
      'cnf_pwd': ['', Validators.required],
      'new_pwd': ['', Validators.required],
      'filename': ['',  ''],
    }, {
      validator: MustMatch('PASSWORD', 'cnf_pwd')
  });
  }
  get f() { return this.formGroup.controls; }
  // getError(el:any) {
  //   this.formGroup.get('username')?.hasError('required');
  //   switch (el) {
  //     case 'user':
  //       if (this.formGroup.get('username')?.hasError('required')) {
  //         return 'Username required';
  //       }else{return ''}
  //       break;
  //     case 'pass':
  //       if (this.formGroup.get('password')?.hasError('required')) {
  //         return 'Password required';
  //       }else{return ''}
  //       break;
  //     default:
  //       return '';
  //   }
  // }
  popupCloseAction:boolean=false;
  onSubmit(popupCloseAction:boolean=false) {
    // this.post = post;
    console.log()
this.popupCloseAction=popupCloseAction;
    let url=environment.SERVICE_APIS.changePwd;
    // if(this.data.editStatus){
    //   url=environment.SERVICE_APIS.updateUser;
    // }
    let CREATED_BY=this.userDataService.userDetails.USER_GUID;
    // this.data.data.USER_GUID='6d0db6c2-7976-422d-ab78-a1667f14fb26';
        let params={
          'PASSWORD':this.formGroup.value.PASSWORD,
          'cnf_pwd':this.formGroup.value.cnf_pwd,
          'new_pwd':this.formGroup.value.new_pwd,
          "CREATED_BY":CREATED_BY,
          "USER_GUID":this.data.data.USER_GUID,
        };
        
        console.log("USER PARAMS::",params);
        // return false;
        this.api.POST_AUTH_BR(url, params, true)
          .subscribe(
            response => {
              console.log("companies response:::",this.popupCloseAction, response);
              // this.dataList=response;
              // this.dataSource = new MatTableDataSource(response['data']);
    // this.setData(response);
    if(!this.popupCloseAction){
      this.dialogRef.disableClose = true;
      this.onNoClick();
    }else{
      
      this.onReset();
    }
    
            },err=>{
              console.log("ERR::",err)
            }
    
          );

  }

  onReset() {
    // this.submitted = false;
    this.formGroup.reset();
}
checkUserIDAvailability(){
  this.userIDstatus=0;
  console.log("",this.formGroup.value.LOGIN_ID);

  let url=environment.SERVICE_APIS.checkUserIDAvailability;

  let CREATED_BY=this.userDataService.userDetails.USER_GUID;
    
        let params={
          'LOGIN_ID':this.formGroup.value.LOGIN_ID
        };
        
        console.log("USER PARAMS::",params);
        // return false;
        this.api.POST_AUTH_BR(url, params, true)
          .subscribe(
            response => {
              console.log("avail resp:::", response.recordset[0].count);
              // this.dataList=response;
              // this.dataSource = new MatTableDataSource(response['data']);
    // this.setData(response);
 this.userIDstatus=response.recordset[0].count;
    
            },err=>{
              console.log("ERR::",err)
            }
    
          );
}
private _filter(value: string): string[] {
  const filterValue = value.toLowerCase();

  return this.options.filter(option => option.toLowerCase().includes(filterValue));
}
private _filter_cust(value: string): string[] {
  const filterValue = value.toLowerCase();
console.log("option logs::",this.optionsc);

  return this.optionsc.filter(option =>option.toLowerCase().includes(filterValue));
}

private _filterd(value: string): string[] {
  const filterValue = value.toLowerCase();
console.log(this.optionsd);
  return this.optionsd.filter(option => option.name.toLowerCase().includes(filterValue));
}

base64File: string = '';
  filename: string = '';

  onFileSelect(e: any): void {
    try {
      const file = e.target.files[0];
      const fReader = new FileReader()
      fReader.readAsDataURL(file)
      fReader.onloadend = (_event: any) => {
        this.filename = file.name;
        this.base64File = _event.target.result;
        // console.log("FILE::",this.base64File);
      }
    } catch (error) {
      this.filename = '';
      this.base64File = '';
      console.log('no file was selected...');
    }
  }

  private setfilteredUserOptions(value: string): string[] {
    const filterValue = value.toLowerCase();
  console.log("filter user list:::",this.userList);
  // this.countryList.filter(option=>);
    return this.userList.filter((option => option.LOGIN_ID.toLowerCase().includes(filterValue)));
  }
  private setfilteredComapnyOptions(value: string): string[] {
    const filterValue = value.toLowerCase();
  console.log("filter company list:::",this.userList);
  // this.countryList.filter(option=>);
    return this.companyList.filter((option => option.COMPANY_NAME.toLowerCase().includes(filterValue)));
  }

   dataURLtoFile(dataurl:any, filename:any) {
    const blob = 
        new Blob([
                 "Please Save Me!"], 
                 {type: "text/plain;charset=utf-8"});
    // saveAs(blob, "./save-me.txt");

    return false;
 console.log("creating file.....")
    var arr = dataurl.split(','),
        mime = arr[0].match(/:(.*?);/)[1],
        bstr = atob(arr[1]), 
        n = bstr.length, 
        u8arr = new Uint8Array(n);
        
    while(n--){
        u8arr[n] = bstr.charCodeAt(n);
    }
    
    return new File([u8arr], filename, {type:mime});
}

}
