import { DatePipe } from '@angular/common';
import { Component, OnInit,Inject } from '@angular/core';
import { FormBuilder,FormGroup, FormControl, Validators} from '@angular/forms';

import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Observable } from 'rxjs';
import { ApiService } from 'src/app/services/api.service';
import {environment} from '../../../environments/environment';
import {MustMatch} from '../../match.validator';

import {map, startWith} from 'rxjs/operators';
import { UserDataService } from 'src/app/services/user-data.service';

@Component({
  selector: 'app-vessel-dialog',
  templateUrl: './vessel-dialog.component.html',
  styleUrls: ['./vessel-dialog.component.scss']
})
export class VesselDialogComponent implements OnInit {

 
  formGroup: FormGroup;
  deptFormControl = new FormControl();
  myControl = new FormControl();
  myControld = new FormControl();
  base64File: string = '';
  filename: string = '';


  companyList: any[] = this.data.companyList;
  companyFilteredData:any=[];

  // deptOptions: any[] = [
  //   {id:1,dept_name:"IT"},
  //   {id:2,dept_name:"NETWORK"},
  //   {id:3,dept_name:"SECURITY"},
  // ];
  options: string[] = ['One', 'Two', 'Three'];
  filteredOptions: Observable<string[]>;

  optionsc: string[] = ['One', 'Two', 'Three','Four'];
  filteredOptionsc: Observable<string[]>;

  optionsd: any[] = [{"id":"1","name":"Dept-1"},{"id":"2","name":"Dept-2"},{"id":"2","name":"Dept-3"}];
  filteredOptionsd: Observable<any[]>;

  userIDstatus:number=0;
  hide_pass = true;
  hide_pass_cnf = true;
  constructor(
    public dialogRef: MatDialogRef<VesselDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,private formBuilder: FormBuilder,private api:ApiService,private datePipe: DatePipe,private userDataService:UserDataService) { 
      dialogRef.disableClose = true;
    }

  onNoClick(): void {
    this.dialogRef.close();
  }

  ngOnInit(): void {
    console.log("ddddddd::",this.data);
    this.createForm();

    this.filteredOptions = this.myControl.valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value)),
    );

    this.filteredOptionsc = this.deptFormControl.valueChanges.pipe(
      startWith(''),
      map(value => this._filter_cust(value)),
    );
    this.filteredOptionsd = this.myControld.valueChanges.pipe(
      startWith(''),
      map(value => this._filterd(value)),
    );
    console.log("===filteredOptions==::",this.filteredOptions);

    this.companyFilteredData = this.formGroup.get('COMPANY_GUID')?.valueChanges.pipe(
      startWith(''),
      map(value => this.setfilteredComapnyOptions(value)),
    );

  }
  createForm() {
    this.formGroup = this.formBuilder.group({
      'VESSEL_NAME': [this.data.data.VESSEL_NAME, Validators.required],
      'VESSEL_TYPE': [this.data.data.VESSEL_TYPE, Validators.required],
      'SHORT_NAME': [this.data.data.SHORT_NAME, ''],
      'COMPANY_GUID': new FormControl(this.data.data.COMPANY_GUID, []),
      'FLAG_ID': [this.data.data.FLAG_ID,''],
      'IMO_NUMBER': [this.data.data.IMO_NUMBER, Validators.required],
      'Port_Of_Registry': [this.data.data.Port_Of_Registry, ''],
      'Call_Sign': [this.data.data.Call_Sign, ''],
      'Photo_Name': [this.data.data.Photo_Name, ''],
      'EMAIL_ID1': [this.data.data.EMAIL_ID1,  ''],
      'EMAIL_ID2': [this.data.data.EMAIL_ID2,  ''],
      'PHONE_NO1': [this.data.data.PHONE_NO1, ''],
      'PHONE_NO2': [this.data.data.PHONE_NO2, ],
      'filename': ['',  ''],
    });
  }
  get f() { return this.formGroup.controls; }
  // getError(el:any) {
  //   this.formGroup.get('username')?.hasError('required');
  //   switch (el) {
  //     case 'user':
  //       if (this.formGroup.get('username')?.hasError('required')) {
  //         return 'Username required';
  //       }else{return ''}
  //       break;
  //     case 'pass':
  //       if (this.formGroup.get('password')?.hasError('required')) {
  //         return 'Password required';
  //       }else{return ''}
  //       break;
  //     default:
  //       return '';
  //   }
  // }
  popupCloseAction:boolean=false;
  onSubmit(popupCloseAction:boolean=false) {
    // this.post = post;
    console.log()
this.popupCloseAction=popupCloseAction;
    let url=environment.SERVICE_APIS.addVessel;
    if(this.data.editStatus){
      url=environment.SERVICE_APIS.updateVessel;
    }
    let CREATED_BY=this.userDataService.userDetails.USER_GUID
    
        let params={
          'VESSEL_NAME':this.formGroup.value.VESSEL_NAME,
          'VESSEL_TYPE':this.formGroup.value.VESSEL_TYPE,
          'SHORT_NAME':this.formGroup.value.SHORT_NAME,
          'COMPANY_GUID':this.formGroup.value.COMPANY_GUID,
          'FLAG_ID':this.formGroup.value.FLAG_ID,
          'IMO_NUMBER':this.formGroup.value.IMO_NUMBER,
          'Port_Of_Registry':this.formGroup.value.Port_Of_Registry,
          'Call_Sign':this.formGroup.value.Call_Sign,
          'Photo_Name':this.base64File,
          'EMAIL_ID1':this.formGroup.value.EMAIL_ID1,
          'EMAIL_ID2':this.formGroup.value.EMAIL_ID2,
          'PHONE_NO1':this.formGroup.value.PHONE_NO1,
          'PHONE_NO2':this.formGroup.value.PHONE_NO2,
          "CREATED_BY":CREATED_BY,
          "VESSEL_GUID":this.data.data.VESSEL_GUID,
        };
        
        console.log("USER PARAMS::",params);
        // return false;
        this.api.POST_AUTH_BR(url, params, true)
          .subscribe(
            response => {
              console.log("companies response:::",this.popupCloseAction, response);
              // this.dataList=response;
              // this.dataSource = new MatTableDataSource(response['data']);
    // this.setData(response);
    if(!this.popupCloseAction){
      this.dialogRef.disableClose = true;
      this.onNoClick();
    }else{
      
      this.onReset();
    }
    
            },err=>{
              console.log("ERR::",err)
            }
    
          );

  }

  onReset() {
    // this.submitted = false;
    this.formGroup.reset();
}
checkUserIDAvailability(){
  this.userIDstatus=0;
  console.log("",this.formGroup.value.LOGIN_ID);

  let url=environment.SERVICE_APIS.checkUserIDAvailability;

  let CREATED_BY=this.userDataService.userDetails.USER_GUID;
    
        let params={
          'LOGIN_ID':this.formGroup.value.LOGIN_ID
        };
        
        console.log("USER PARAMS::",params);
        // return false;
        this.api.POST_AUTH_BR(url, params, true)
          .subscribe(
            response => {
              console.log("avail resp:::", response.recordset[0].count);
              // this.dataList=response;
              // this.dataSource = new MatTableDataSource(response['data']);
    // this.setData(response);
 this.userIDstatus=response.recordset[0].count;
    
            },err=>{
              console.log("ERR::",err)
            }
    
          );
}
private _filter(value: string): string[] {
  const filterValue = value.toLowerCase();

  return this.options.filter(option => option.toLowerCase().includes(filterValue));
}
private _filter_cust(value: string): string[] {
  const filterValue = value.toLowerCase();
console.log("option logs::",this.optionsc);

  return this.optionsc.filter(option =>option.toLowerCase().includes(filterValue));
}

private _filterd(value: string): string[] {
  const filterValue = value.toLowerCase();
console.log(this.optionsd);
  return this.optionsd.filter(option => option.name.toLowerCase().includes(filterValue));
}


  onFileSelect(e: any): void {
    try {
      const file = e.target.files[0];
      const fReader = new FileReader()
      fReader.readAsDataURL(file)
      fReader.onloadend = (_event: any) => {
        this.filename = file.name;
        this.base64File = _event.target.result;
        // console.log("FILE::",this.base64File);
      }
    } catch (error) {
      this.filename = '';
      this.base64File = '';
      console.log('no file was selected...');
    }
  }

  private setfilteredComapnyOptions(value: string): string[] {
    const filterValue = value.toLowerCase();
  console.log("filter company list:::",this.companyList);
  // this.countryList.filter(option=>);
    return this.companyList.filter((option => option.COMPANY_NAME.toLowerCase().includes(filterValue)));
  }

}
