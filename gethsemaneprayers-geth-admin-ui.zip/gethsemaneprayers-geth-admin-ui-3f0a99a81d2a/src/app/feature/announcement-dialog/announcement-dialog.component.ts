import { DatePipe } from '@angular/common';
import { Component, OnInit,Inject } from '@angular/core';
import { FormBuilder,FormGroup, FormControl, Validators} from '@angular/forms';

import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Observable } from 'rxjs';
import { ApiService } from 'src/app/services/api.service';
import {environment} from '../../../environments/environment';
import {MustMatch} from '../../match.validator';

import {map, startWith} from 'rxjs/operators';
import { UserDetailsService } from 'src/app/services/user-details.service';

@Component({
  selector: 'app-announcement-dialog',
  templateUrl: './announcement-dialog.component.html',
  styleUrls: ['./announcement-dialog.component.scss']
})
export class AnnouncementDialogComponent implements OnInit {


 
  formGroup: FormGroup;
  promiseTypeList: any[] = this.data.promiseTypeList;

  
  promiseTypeFilteredData:any=[];

  userIDstatus:number=0;
  hide_pass = true;
  hide_pass_cnf = true;
  base64File: string = '';
  filename: string = '';
  fileProps:any=[];
  constructor(
    public dialogRef: MatDialogRef<AnnouncementDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,private formBuilder: FormBuilder,private api:ApiService,private datePipe: DatePipe,private userDetailsService:UserDetailsService) { 
      dialogRef.disableClose = true;
    }

  onNoClick(): void {
    this.dialogRef.close();
  }

  ngOnInit(): void {
    console.log("ddddddd::",this.data);
    this.createForm();

   
  
    this.promiseTypeFilteredData = this.formGroup.get('promise_type')?.valueChanges.pipe(
      startWith(''),
      map(value => this.setfilteredPromiseTypeOptions(value)),
    );
  }
  
  createForm() {
    this.formGroup = this.formBuilder.group({
      'description': [this.data.data.description, Validators.required],
      'info': [this.data.data.info, ''],
      'valid_to': [this.data.data.valid_to, Validators.required],
      'file_path': ["", ""],
      'filename': ['',  ''],
    });
  }
  get f() { return this.formGroup.controls; }
  // getError(el:any) {
  //   this.formGroup.get('username')?.hasError('required');
  //   switch (el) {
  //     case 'user':
  //       if (this.formGroup.get('username')?.hasError('required')) {
  //         return 'Username required';
  //       }else{return ''}
  //       break;
  //     case 'pass':
  //       if (this.formGroup.get('password')?.hasError('required')) {
  //         return 'Password required';
  //       }else{return ''}
  //       break;
  //     default:
  //       return '';
  //   }
  // }
  popupCloseAction:boolean=false;
  onSubmit(popupCloseAction:boolean=false) {
    // this.post = post;
    console.log()
this.popupCloseAction=popupCloseAction;
    let url=environment.SERVICE_APIS.addAnnouncement;
    if(this.data.editStatus){
      url=environment.SERVICE_APIS.updateAnnouncement;
    }
    let uniq_id=this.userDetailsService.userInfo.uniq_id;
    let global_cid=this.userDetailsService.userInfo.global_cid;
    
        let params={
          'description':this.formGroup.value.description,
          'info':this.formGroup.value.info,
          'valid_to':this.formGroup.value.valid_to,
          'type':'ADMIN',
          'global_cid':global_cid,
          "uniq_id":uniq_id,
          "id":this.data.data.id,
        };
        
        console.log("USER PARAMS::",params);
        // return false;
        this.api.POST_AUTH_BR(url, params, true)
          .subscribe(
            response => {
              console.log("companies response:::",this.popupCloseAction, response);
              // this.dataList=response;
              // this.dataSource = new MatTableDataSource(response['data']);
    // this.setData(response);
    if(!this.popupCloseAction){
      this.dialogRef.disableClose = true;
      this.onNoClick();
    }else{
      
      this.onReset();
    }
    
            },err=>{
              console.log("ERR::",err)
            }
    
          );

  }

  onReset() {
    // this.submitted = false;
    this.formGroup.reset();
}


private setfilteredPromiseTypeOptions(value: string): string[] {
 
 
  const filterValue = value.toLowerCase();
// console.log("filter company list:::",this.userList);
// this.countryList.filter(option=>);
  return this.promiseTypeList.filter((option => option.promise_type.toLowerCase().includes(filterValue)));

}



  onFileSelect(e: any): void {
    try {
      const file = e.target.files[0];
      const fReader = new FileReader()
      fReader.readAsDataURL(file)
      fReader.onloadend = (_event: any) => {
        this.filename = file.name;
        this.base64File = _event.target.result;
        console.log("filename::",this.filename);
        console.log("file pros::",file);
        this.fileProps=file;
        // console.log("FILE base64::",this.base64File);
      }
    } catch (error) {
      this.filename = '';
      this.base64File = '';
      console.log('no file was selected...');
    }
  }


}

