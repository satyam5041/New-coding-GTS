import { DatePipe } from '@angular/common';
import { Component, OnInit,Inject } from '@angular/core';
import { FormBuilder,FormGroup, FormControl, Validators} from '@angular/forms';

import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Observable } from 'rxjs';
import { ApiService } from 'src/app/services/api.service';
import {environment} from '../../../environments/environment';
import {MustMatch} from '../../match.validator';

import {map, startWith} from 'rxjs/operators';
import { UserDetailsService } from 'src/app/services/user-details.service';
// import { UserDataService } from 'src/app/services/user-data.service';

@Component({
  selector: 'app-goals-dialog',
  templateUrl: './goals-dialog.component.html',
  styleUrls: ['./goals-dialog.component.scss']
})
export class GoalsDialogComponent implements OnInit {

 
 
  formGroup: FormGroup;
  deptFormControl = new FormControl();
  myControl = new FormControl();
  myControld = new FormControl();
  typeList: any[] = this.data.typeList;
  timeList: any[] = this.data.timeList;
  // deptOptions: any[] = [
  //   {id:1,dept_name:"IT"},
  //   {id:2,dept_name:"NETWORK"},
  //   {id:3,dept_name:"SECURITY"},
  // ];
  options: string[] = ['One', 'Two', 'Three'];
  filteredOptions: Observable<string[]>;

  optionsc: string[] = ['One', 'Two', 'Three','Four'];
  filteredOptionsc: Observable<string[]>;

  optionsd: any[] = [{"id":"1","name":"Dept-1"},{"id":"2","name":"Dept-2"},{"id":"2","name":"Dept-3"}];
  filteredOptionsd: Observable<any[]>;
  typeFilteredData:any=[];
  timeFilteredData:any=[];

  userIDstatus:number=0;
  hide_pass = true;
  hide_pass_cnf = true;
  constructor(
    public dialogRef: MatDialogRef<GoalsDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,private formBuilder: FormBuilder,private api:ApiService,private datePipe: DatePipe,private userDetailsService:UserDetailsService) { 
      dialogRef.disableClose = true;
    }

  onNoClick(): void {
    this.dialogRef.close();
  }

  ngOnInit(): void {
    console.log("ddddddd::",this.data);
    this.createForm();

    this.filteredOptions = this.myControl.valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value)),
    );

    this.filteredOptionsc = this.deptFormControl.valueChanges.pipe(
      startWith(''),
      map(value => this._filter_cust(value)),
    );
    this.filteredOptionsd = this.myControld.valueChanges.pipe(
      startWith(''),
      map(value => this._filterd(value)),
    );
    console.log("===filteredOptions==::",this.filteredOptions);

    this.typeFilteredData = this.formGroup.get('type')?.valueChanges.pipe(
      startWith(''),
      map(value => this.setfilteredTypeOptions(value)),
    );
    this.timeFilteredData = this.formGroup.get('goal_time')?.valueChanges.pipe(
      startWith(''),
      map(value => this.setfilteredTimeOptions(value)),
    );
  }
  
  createForm() {
    this.formGroup = this.formBuilder.group({
      'title': [this.data.data.title, Validators.required],
      'description': [this.data.data.description, Validators.required],
      'type': [this.data.data.type, ''],
      'goal_time': [this.data.data.goal_time, Validators.required],
      'goal_end_date': [this.data.data.goal_end_date,''],
      'goal_pic': [this.data.data.goal_pic, ''],
      'filename': ['',  ''],
    });
  }
  get f() { return this.formGroup.controls; }
  // getError(el:any) {
  //   this.formGroup.get('username')?.hasError('required');
  //   switch (el) {
  //     case 'user':
  //       if (this.formGroup.get('username')?.hasError('required')) {
  //         return 'Username required';
  //       }else{return ''}
  //       break;
  //     case 'pass':
  //       if (this.formGroup.get('password')?.hasError('required')) {
  //         return 'Password required';
  //       }else{return ''}
  //       break;
  //     default:
  //       return '';
  //   }
  // }
  popupCloseAction:boolean=false;
  onSubmit(popupCloseAction:boolean=false) {
    // this.post = post;
    console.log()
this.popupCloseAction=popupCloseAction;
    let url=environment.SERVICE_APIS.createGoal;
    // if(this.data.editStatus){
    //   url=environment.SERVICE_APIS.updateCountry;
    // }
    let uniq_id=this.userDetailsService.userInfo.uniq_id;
    
        let params={
          'title':this.formGroup.value.title,
          'description':this.formGroup.value.description,
          'type':this.formGroup.value.type,
          'goal_time':this.formGroup.value.goal_time,
          'goal_end_date':this.formGroup.value.goal_end_date,
          'goal_pic':this.formGroup.value.goal_pic,
          "uniq_id":uniq_id,
        };
        
        console.log("USER PARAMS::",params);
        // return false;
        this.api.POST_AUTH_BR(url, params, true)
          .subscribe(
            response => {
              console.log("companies response:::",this.popupCloseAction, response);
              // this.dataList=response;
              // this.dataSource = new MatTableDataSource(response['data']);
    // this.setData(response);
    if(!this.popupCloseAction){
      this.dialogRef.disableClose = true;
      this.onNoClick();
    }else{
      
      this.onReset();
    }
    
            },err=>{
              console.log("ERR::",err)
            }
    
          );

  }

  onReset() {
    // this.submitted = false;
    this.formGroup.reset();
}

private _filter(value: string): string[] {
  const filterValue = value.toLowerCase();

  return this.options.filter(option => option.toLowerCase().includes(filterValue));
}
private _filter_cust(value: string): string[] {
  const filterValue = value.toLowerCase();
console.log("option logs::",this.optionsc);

  return this.optionsc.filter(option =>option.toLowerCase().includes(filterValue));
}

private _filterd(value: string): string[] {
  const filterValue = value.toLowerCase();
console.log(this.optionsd);
  return this.optionsd.filter(option => option.name.toLowerCase().includes(filterValue));
}
private setfilteredTypeOptions(value: string): string[] {
  const filterValue = value.toLowerCase();
// console.log("filter company list:::",this.userList);
// this.countryList.filter(option=>);
  return this.typeList.filter((option => option.text.toLowerCase().includes(filterValue)));
}
private setfilteredTimeOptions(value: string): string[] {
  const filterValue = value.toLowerCase();
// console.log("filter company list:::",this.userList);
// this.countryList.filter(option=>);
  return this.timeList.filter((option => option.text.toLowerCase().includes(filterValue)));
}

base64File: string = '';
  filename: string = '';

  onFileSelect(e: any): void {
    try {
      const file = e.target.files[0];
      const fReader = new FileReader()
      fReader.readAsDataURL(file)
      fReader.onloadend = (_event: any) => {
        this.filename = file.name;
        this.base64File = _event.target.result;
        // console.log("FILE::",this.base64File);
      }
    } catch (error) {
      this.filename = '';
      this.base64File = '';
      console.log('no file was selected...');
    }
  }

}
