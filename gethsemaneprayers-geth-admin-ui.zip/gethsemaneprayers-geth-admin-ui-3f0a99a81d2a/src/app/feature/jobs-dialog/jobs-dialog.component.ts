import { DatePipe } from '@angular/common';
import { Component, OnInit,Inject } from '@angular/core';
import { FormBuilder,FormGroup, FormControl, Validators} from '@angular/forms';

import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Observable } from 'rxjs';
import { ApiService } from 'src/app/services/api.service';
import {environment} from '../../../environments/environment';
import {MustMatch} from '../../match.validator';

import {map, startWith} from 'rxjs/operators';
import { UserDetailsService } from 'src/app/services/user-details.service';

@Component({
  selector: 'app-jobs-dialog',
  templateUrl: './jobs-dialog.component.html',
  styleUrls: ['./jobs-dialog.component.scss']
})
export class JobsDialogComponent implements OnInit {


 
  formGroup: FormGroup;
  promiseTypeList: any[] = this.data.promiseTypeList;

  
  promiseTypeFilteredData:any=[];

  userIDstatus:number=0;
  hide_pass = true;
  hide_pass_cnf = true;
  base64File: string = '';
  filename: string = '';
  fileProps:any=[];
  constructor(
    public dialogRef: MatDialogRef<JobsDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,private formBuilder: FormBuilder,private api:ApiService,private datePipe: DatePipe,private userDetailsService:UserDetailsService) { 
      dialogRef.disableClose = true;
    }


    genderList = [
      {
        id: '',
        name: '--Select--'
      },
      {
        id: 'MALE',
        name: 'Male'
      },
      {
        id: 'FEMALE',
        name: 'Female'
      },
      {
        id: 'OTHERS',
        name: 'Others'
      },
      {
        id: 'ANY',
        name: 'Any'
      },
      
      
    ];

    statusList = [
      {
        id: '',
        name: '--Select--'
      },
      {
        id: 'OPEN',
        name: 'Open'
      },
      {
        id: 'CLOSED',
        name: 'Closed'
      },
      {
        id: 'HOLD',
        name: 'Hold'
      },
    ];
    
    jobCountryList = [
      {
        id: '',
        name: '--Select--'
      },
      {
        id: 'IN',
        name: 'india'
      },
    
    ];
    jobTypeList = [
      {
        id: '',
        name: '--Select--'
      },
      {
        id: 'FULL_TIME',
        name: 'full time/parmanent'
      },
      {
        id: 'PART_TIME',
        name: 'part time'
      },
      {
        id: 'SHIFTS',
        name: 'shift'
      },
      {
        id: 'CONTRACT',
        name: 'contract'
      },
    
    ];

  onNoClick(): void {
    this.dialogRef.close();
  }

  ngOnInit(): void {
    console.log("ddddddd::",this.data);
    this.createForm();

   
  
    this.promiseTypeFilteredData = this.formGroup.get('promise_type')?.valueChanges.pipe(
      startWith(''),
      map(value => this.setfilteredPromiseTypeOptions(value)),
    );
  }
  
  createForm() {
    this.formGroup = this.formBuilder.group({
      'name': [this.data.data.name, Validators.required],
      'skills': [this.data.data.skills, Validators.required],
      'addr': [this.data.data.addr, Validators.required],
      'salary': [this.data.data.salary, Validators.required],
      'qualification': [this.data.data.qualification, Validators.required],
      'gender': [this.data.data.gender, Validators.required],
      'open_positions': [this.data.data.open_positions, Validators.required],
      'open_status': [this.data.data.open_status, Validators.required],
      'company': [this.data.data.company, Validators.required],
      'role': [this.data.data.role, Validators.required],
      'city': [this.data.data.city, Validators.required],
      'mob': [this.data.data.mob, Validators.required],
      'email': [this.data.data.email, ''],
      'description': [this.data.data.description,Validators.required],
      'other_info': [this.data.data.other_info, ''],
      'job_type': [this.data.data.job_type, Validators.required],
      'salary_max': [this.data.data.salary_max, Validators.required],
      'job_country': [this.data.data.job_country, Validators.required],
      'exp': [this.data.data.exp, Validators.required],
      'file_path': ["", ""],
      'filename': ['',  ''],
    });
  }
  get f() { return this.formGroup.controls; }
  // getError(el:any) {
  //   this.formGroup.get('username')?.hasError('required');
  //   switch (el) {
  //     case 'user':
  //       if (this.formGroup.get('username')?.hasError('required')) {
  //         return 'Username required';
  //       }else{return ''}
  //       break;
  //     case 'pass':
  //       if (this.formGroup.get('password')?.hasError('required')) {
  //         return 'Password required';
  //       }else{return ''}
  //       break;
  //     default:
  //       return '';
  //   }
  // }
  popupCloseAction:boolean=false;
  onSubmit(popupCloseAction:boolean=false) {
    // this.post = post;
    console.log()
this.popupCloseAction=popupCloseAction;
    let url=environment.SERVICE_APIS.addCorporateJob;
    if(this.data.editStatus){
      url=environment.SERVICE_APIS.updateCorporateJob;
    }
    let uniq_id=this.userDetailsService.userInfo.uniq_id;
    let global_cid=this.userDetailsService.userInfo.global_cid;
    
        let params={
          'name':this.formGroup.value.name,
          'skills':this.formGroup.value.skills,
          'addr':this.formGroup.value.addr,
          'salary':this.formGroup.value.salary,
          'qualification':this.formGroup.value.qualification,
          'gender':this.formGroup.value.gender,
          'open_positions':this.formGroup.value.open_positions,
          'open_status':this.formGroup.value.open_status,
          'company':this.formGroup.value.company,
          'role':this.formGroup.value.role,
          'city':this.formGroup.value.city,
          'mob':this.formGroup.value.mob,
          'email':this.formGroup.value.email,
          'description':this.formGroup.value.description,
          'other_info':this.formGroup.value.other_info,
          'job_type':this.formGroup.value.job_type,
          'salary_max':this.formGroup.value.salary_max,
          'job_country':this.formGroup.value.job_country,
          'exp':this.formGroup.value.exp,
          'id':this.data.data.id,
          'global_cid':global_cid,
          "uniq_id":uniq_id,
        };
        
        console.log("USER PARAMS::",params);
        // return false;
        this.api.POST_AUTH_BR(url, params, true)
          .subscribe(
            response => {
              console.log("companies response:::",this.popupCloseAction, response);
              // this.dataList=response;
              // this.dataSource = new MatTableDataSource(response['data']);
    // this.setData(response);
    if(!this.popupCloseAction){
      this.dialogRef.disableClose = true;
      this.onNoClick();
    }else{
      
      this.onReset();
    }
    
            },err=>{
              console.log("ERR::",err)
            }
    
          );

  }

  onReset() {
    // this.submitted = false;
    this.formGroup.reset();
}


private setfilteredPromiseTypeOptions(value: string): string[] {
 
 
  const filterValue = value.toLowerCase();
// console.log("filter company list:::",this.userList);
// this.countryList.filter(option=>);
  return this.promiseTypeList.filter((option => option.promise_type.toLowerCase().includes(filterValue)));

}



  onFileSelect(e: any): void {
    try {
      const file = e.target.files[0];
      const fReader = new FileReader()
      fReader.readAsDataURL(file)
      fReader.onloadend = (_event: any) => {
        this.filename = file.name;
        this.base64File = _event.target.result;
        console.log("filename::",this.filename);
        console.log("file pros::",file);
        this.fileProps=file;
        // console.log("FILE base64::",this.base64File);
      }
    } catch (error) {
      this.filename = '';
      this.base64File = '';
      console.log('no file was selected...');
    }
  }


}
