import { Component } from '@angular/core';
import { UserDataService } from './services/user-data.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  constructor(private userDataService:UserDataService){
    console.log("APP  Component::",this.userDataService.loginStatus);
   
  }
  ngAfterViewInit(){
    this.userDataService.loginStatus.subscribe(data=>console.log("APPPPPP",data));
  }
  title = 'magentis';
}
