import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {HttpClientModule} from '@angular/common/http';
import {MatNativeDateModule} from '@angular/material/core';
import { MtxTooltipModule } from '@ng-matero/extensions/tooltip';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MenuBarComponent } from './menu-bar/menu-bar.component';
import { FooterBarComponent } from './footer-bar/footer-bar.component';
import { LandingComponent } from './landing/landing.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from './material.module';
import { LoginComponent } from './components/login/login.component';
import { ForgotPasswordComponent } from './components/forgot-password/forgot-password.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { SideNavComponent } from './side-nav/side-nav.component';
import { CarouselComponent } from './components/carousel/carousel.component';
import { IvyCarouselModule } from 'angular-responsive-carousel';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MatCarouselModule } from '@ngmodule/material-carousel';
import { CommonModule, DatePipe} from '@angular/common';
import { CreateGoalComponent } from './components/create-goal/create-goal.component';
import { PrayerRequestAddComponent } from './components/prayer-request-add/prayer-request-add.component';
import { PrayerSelfComponent } from './components/prayer-self/prayer-self.component';
import { JobsComponent } from './components/jobs/jobs.component';
import { SmallDialogComponent } from './feature/small-dialog/small-dialog.component';
import { ChainPrayersComponent } from './components/chain-prayers/chain-prayers.component';
import { ForumComponent } from './components/forum/forum.component';
import { PublicPrayersComponent } from './components/public-prayers/public-prayers.component';
import { OnlinePrayerBlogComponent } from './components/online-prayer-blog/online-prayer-blog.component';
import { CalendarComponent } from './components/calendar/calendar.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { CompaniesComponent } from './components/companies/companies.component';
import { CompaniesDialogComponent } from './feature/companies-dialog/companies-dialog.component';
import { UserComponent } from './components/user/user.component';
import { UserDialogComponent } from './feature/user-dialog/user-dialog.component';
import { VesselDialogComponent } from './feature/vessel-dialog/vessel-dialog.component';
import { VesselComponent } from './components/vessel/vessel.component';
import { PortsComponent } from './components/ports/ports.component';
import { PortDialogComponent } from './feature/port-dialog/port-dialog.component';
import { CountryDialogComponent } from './feature/country-dialog/country-dialog.component';
import { CountryComponent } from './components/country/country.component';
import { CurrencyComponent } from './components/currency/currency.component';
import { CurrencyDialogComponent } from './feature/currency-dialog/currency-dialog.component';
import { ChangePasswordDialogComponent } from './feature/change-password-dialog/change-password-dialog.component';
import { HomeCarouselComponent } from './components/home-carousel/home-carousel.component';
import { NexteventComponent } from './components/nextevent/nextevent.component';
import { WelcomeBlockComponent } from './components/welcome-block/welcome-block.component';
import { WorshipComponent } from './components/worship/worship.component';
import { WorshipteamComponent } from './components/worshipteam/worshipteam.component';
import { FromOurBlogComponent } from './components/from-our-blog/from-our-blog.component';
import { JoingroupComponent } from './components/joingroup/joingroup.component';
import { FootersComponent } from './components/footers/footers.component';

import { CarouselModule } from 'ngx-owl-carousel-o';
import { GoalsDialogComponent } from './feature/goals-dialog/goals-dialog.component';
import { MyPromisesComponent } from './components/my-promises/my-promises.component';
import { MyPromiseDialogComponent } from './feature/my-promise-dialog/my-promise-dialog.component';
import { AnnounementComponent } from './components/announement/announement.component';
import { AnnouncementDialogComponent } from './feature/announcement-dialog/announcement-dialog.component';
import { PromiselandComponent } from './components/promiseland/promiseland.component';
import { PromiselandDialogComponent } from './feature/promiseland-dialog/promiseland-dialog.component';
import { MessagesComponent } from './components/messages/messages.component';
import { MessagesDialogComponent } from './feature/messages-dialog/messages-dialog.component';
import { JobsDialogComponent } from './feature/jobs-dialog/jobs-dialog.component';
import { WeeklyserviceComponent } from './components/weeklyservice/weeklyservice.component';
import { WeeklyserviceDialogComponent } from './feature/weeklyservice-dialog/weeklyservice-dialog.component';
import { ChainprayerComponent } from './components/chainprayer/chainprayer.component';
import { ChainprayerDialogComponent } from './feature/chainprayer-dialog/chainprayer-dialog.component';
import { LeadershipComponent } from './components/leadership/leadership.component';
import { LeadershipDialogComponent } from './feature/leadership-dialog/leadership-dialog.component';
import { ProductsComponent } from './components/products/products.component';
import { ProductsDialogComponent } from './feature/products-dialog/products-dialog.component';
import { MatrimonyComponent } from './components/matrimony/matrimony.component';
import { MatrimonyDialogComponent } from './feature/matrimony-dialog/matrimony-dialog.component';
import { PurchaseordersComponent } from './components/purchaseorders/purchaseorders.component';
import { ChurchComponent } from './components/church/church.component';
import { ChurchDialogComponent } from './feature/church-dialog/church-dialog.component';
import { SuggestionsComponent } from './components/suggestions/suggestions.component';
import { PrayerrequestsComponent } from './components/prayerrequests/prayerrequests.component';
//import { AnnounementComponent } from './announement/announement.component';
@NgModule({
  declarations: [
    AppComponent,
    MenuBarComponent,
    FooterBarComponent,
    LandingComponent,
    LoginComponent,
    ForgotPasswordComponent,
    RegistrationComponent,
    SideNavComponent,
    CarouselComponent,
    CreateGoalComponent,
    PrayerRequestAddComponent,
    PrayerSelfComponent,
    JobsComponent,
    SmallDialogComponent,
    ChainPrayersComponent,
    ForumComponent,
    PublicPrayersComponent,
    OnlinePrayerBlogComponent,
    CalendarComponent,
    DashboardComponent,
    PageNotFoundComponent,
    CompaniesComponent,
    CompaniesDialogComponent,
    UserComponent,
    UserDialogComponent,
    VesselDialogComponent,
    VesselComponent,
    PortsComponent,
    PortDialogComponent,
    CountryDialogComponent,
    CountryComponent,
    CurrencyComponent,
    CurrencyDialogComponent,
    ChangePasswordDialogComponent,
    HomeCarouselComponent,
    NexteventComponent,
    WelcomeBlockComponent,
    WorshipComponent,
    WorshipteamComponent,
    FromOurBlogComponent,
    JoingroupComponent,
    FootersComponent,
    GoalsDialogComponent,
    MyPromisesComponent,
    MyPromiseDialogComponent,
    AnnounementComponent,
    AnnouncementDialogComponent,
    PromiselandComponent,
    PromiselandDialogComponent,
    MessagesComponent,
    MessagesDialogComponent,
    JobsDialogComponent,
    WeeklyserviceComponent,
    WeeklyserviceDialogComponent,
    ChainprayerComponent,
    ChainprayerDialogComponent,
    LeadershipComponent,
    LeadershipDialogComponent,
    ProductsComponent,
    ProductsDialogComponent,
    MatrimonyComponent,
    MatrimonyDialogComponent,
    PurchaseordersComponent,
    ChurchComponent,
    ChurchDialogComponent,
    SuggestionsComponent,
    PrayerrequestsComponent,
  ],
  imports: [
    BrowserModule,
    CommonModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    MaterialModule,
    MatNativeDateModule,
    ReactiveFormsModule,
    IvyCarouselModule,
    MtxTooltipModule,
    NgbModule,
    MatCarouselModule,
    CarouselModule
  ],
  providers: [DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
