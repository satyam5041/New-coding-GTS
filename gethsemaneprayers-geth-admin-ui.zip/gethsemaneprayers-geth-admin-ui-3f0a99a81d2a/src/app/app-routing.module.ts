import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ChainPrayersComponent } from './components/chain-prayers/chain-prayers.component';
import { CompaniesComponent } from './components/companies/companies.component';
import { CountryComponent } from './components/country/country.component';
import { CreateGoalComponent } from './components/create-goal/create-goal.component';
import { CurrencyComponent } from './components/currency/currency.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ForgotPasswordComponent } from './components/forgot-password/forgot-password.component';
import { JobsComponent } from './components/jobs/jobs.component';
import { LoginComponent } from './components/login/login.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { PortsComponent } from './components/ports/ports.component';
import { PrayerRequestAddComponent } from './components/prayer-request-add/prayer-request-add.component';
import { PrayerSelfComponent } from './components/prayer-self/prayer-self.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { UserComponent } from './components/user/user.component';
import { VesselComponent } from './components/vessel/vessel.component';
import { LandingComponent } from './landing/landing.component';
import { ForumComponent } from './components/forum/forum.component';
import { PublicPrayersComponent } from './components/public-prayers/public-prayers.component';
import { OnlinePrayerBlogComponent } from './components/online-prayer-blog/online-prayer-blog.component';
import { CalendarComponent } from './components/calendar/calendar.component';
import { AuthGuardGuard } from './services/auth-guard.guard';
import { MyPromisesComponent } from './components/my-promises/my-promises.component';
import { AnnounementComponent } from './components/announement/announement.component';
import { PromiselandComponent } from './components/promiseland/promiseland.component';
import { MessagesComponent } from './components/messages/messages.component';
import { WeeklyserviceComponent } from './components/weeklyservice/weeklyservice.component';
import { ChainprayerComponent } from './components/chainprayer/chainprayer.component';
import { LeadershipComponent } from './components/leadership/leadership.component';
import { ProductsComponent } from './components/products/products.component';
import { MatrimonyComponent } from './components/matrimony/matrimony.component';
import { PurchaseordersComponent } from './components/purchaseorders/purchaseorders.component';
import { ChurchComponent } from './components/church/church.component';
import { SuggestionsComponent } from './components/suggestions/suggestions.component';
import { PrayerrequestsComponent } from './components/prayerrequests/prayerrequests.component';

// const routes: Routes = [
//   {path:"",component:LandingComponent},
//   {path:"login",component:LoginComponent},
//   {path:"forgot-password",component:ForgotPasswordComponent},
//   {path:"registration",component:RegistrationComponent},
//   {path:"addgoal",component:CreateGoalComponent},
//   {path:"addprayer",component:PrayerRequestAddComponent},
//   {path:"myprayers",component:PrayerSelfComponent},
//   {path:"jobs",component:JobsComponent},
//   {path:"chainprayers",component:ChainPrayersComponent},
//   {path:"forum",component:ForumComponent},
//   {path:"public-prayers",component:PublicPrayersComponent},
//   {path:"online-prayer-blog",component:OnlinePrayerBlogComponent},
//   {path:"calendar",component:CalendarComponent},


const routes: Routes = [
  { path: "landing", component: LandingComponent },
  { path: "", component: LoginComponent },
  { path: "dashboard", component: DashboardComponent,
  canActivate: [AuthGuardGuard] },
  { path: "companies", component: CompaniesComponent },
  { path: "user", component: UserComponent },
  { path: "vessel", component: VesselComponent },
  { path: "ports", component: PortsComponent },
  { path: "countries", component: CountryComponent },
  { path: "currencies", component: CurrencyComponent },


  { path: "login", component: LoginComponent },
  { path: "forgot-password", component: ForgotPasswordComponent },
  { path: "registration", component: RegistrationComponent },

  {
    path: "addgoal", component: CreateGoalComponent
  },
  {
    path: "mypromises", component: MyPromisesComponent
  },

  //{ path: "addprayer", component: PrayerRequestAddComponent },
  { path: "myprayers", component: PrayerSelfComponent },
  { path: "jobs", component: JobsComponent },
  { path: "chainprayers", component: ChainPrayersComponent },

  {path:"forum",component:ForumComponent},
  {path:"public-prayers",component:PublicPrayersComponent},
  {path:"online-prayer-blog",component:OnlinePrayerBlogComponent},
  {path:"calendar",component:CalendarComponent},
  { path: "announcements", component: AnnounementComponent },
  { path: "promiseland", component: PromiselandComponent },
  { path: "messages", component: MessagesComponent },
  { path: "weeklyservice", component: WeeklyserviceComponent },
  { path: "chainprayer", component: ChainprayerComponent },
  { path: "leadership", component: LeadershipComponent },
  { path: "products", component: ProductsComponent },
  { path: "matrimony", component: MatrimonyComponent },
  { path: "purchaseorders", component: PurchaseordersComponent },
  { path: "church", component: ChurchComponent },
  { path: "suggestions", component: SuggestionsComponent },
  { path: "prayerrequests", component: PrayerrequestsComponent },


  { path: "pagenotfound", component: PageNotFoundComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
