import { Component, OnInit,HostListener,ViewChild } from '@angular/core';
import {FormControl} from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatAccordion } from '@angular/material/expansion';
import { Router } from '@angular/router';
// import { LoginComponent } from '../components/login/login.component';
import { ChangePasswordDialogComponent } from '../feature/change-password-dialog/change-password-dialog.component';
import { UserDataService } from '../services/user-data.service';
@Component({
  selector: 'app-side-nav',
  templateUrl: './side-nav.component.html',
  styleUrls: ['./side-nav.component.scss']
})
export class SideNavComponent implements OnInit {
  isSticky: boolean = false;
  @ViewChild(MatAccordion) accordion: MatAccordion;
  // @ViewChild('loginComponent') loginComponent: LoginComponent;
  @HostListener('window:scroll', ['$event'])
  checkScroll() {
    console.log('ssss',window.pageYOffset)
    this.isSticky = window.pageYOffset >= 25;
  }
  loginStatus:boolean=false;
  constructor(private router:Router,public dialog: MatDialog,private userDataService:UserDataService) {
    // this.loginStatus=this.userDataService.loginStatus;
    this.userDataService.stringSubject.subscribe(
      data => 
      {
        console.log('next subscribed value side NAVVVV: ' + data);
        // this.name = data;
      }
    );

    this.userDataService.loginStatus.subscribe(
      data => 
      {
        
        this.setLoginSts(data);
        // this.name = data;
      }
    );
   }
  //  loginStatus:boolean=false;
   setLoginSts(data:any){
     let d:any=JSON.stringify(data);
    console.log('next login ssss: ' + JSON.stringify(data));
    let loginData = JSON.parse(d); 
    this.loginStatus=loginData.loginStatus;
    console.log(this.loginStatus,loginData);
   }
  mode = new FormControl('over');
  shouldRun = [/(^|\.)plnkr\.co$/, /(^|\.)stackblitz\.io$/].some(h => h.test(window.location.host));
  // typesOfShoes: string[] = ['Boots', 'Clogs', 'Loafers', 'Moccasins', 'Sneakers'];
  menuItems: any[] = [
    {"name":"Home","link":""},
    {"name":"Dashboard","link":"dashboard"},
    {"name":"Login","link":"login"},
    //{"name":"Registration","link":"registration"},
    {"name":"Forgot Password","link":"forgot-password"},
   // {"name":"Goal","link":"addgoal"},
  {"name":"Promises","link":"mypromises"},
    //{"name":"Add Prayer","link":"addprayer"},
    //{"name":"My Prayers","link":"myprayers"},
    {"name":"Jobs","link":"jobs"},
   // {"name":"Chain Prayers","link":"chainprayers"},
   // {"name":"Online Prayers","link":"public-prayers"},
   // {"name":"Forum","link":"forum"},
    {"name":"Announcements","link":"announcements"},
    {"name":"Messages","link":"messages"},
    {"name":"Promise Land","link":"promiseland"},
    {"name":"weekly service","link":"weeklyservice"},
    {"name":"chainprayer","link":"chainprayer"},
    {"name":"leadership","link":"leadership"},
    {"name":"products","link":"products"},
    {"name":"matrimony","link":"matrimony"},
    {"name":"purchaseorders","link":"purchaseorders"},
    {"name":"church","link":"church"},
    {"name":"suggestions","link":"suggestions"},
    {"name":"prayerrequests","link":"prayerrequests"},
  ];
  test:any='side nav';
  ngOnInit(): void {
  }
  ngAfterViewInit() {
    // console.log("LLLLLL::",this.loginComponent.test)
  }
  goTo(l:string){
this.router.navigateByUrl(l);
  }
  clickedP(){
console.log('sddddd')
  }

  changePwdDialog(data:any,editStatus:boolean=false): void {
    console.log("COMP DATA::",data,editStatus)
    let dialogRef = this.dialog.open(ChangePasswordDialogComponent, {
      width: '50%',
      data: { title: 'Heading', caption: `caption`,message:'Hello Meassag',close_btn:'Close',submit_btn_1:editStatus?'Update & Close':'Submit & Close',submit_btn_2:'',data:this.userDataService.userDetails ,editStatus:editStatus}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed',result);
      // this.getCountries();
      // this.animal = result;
    });
  }

  logout(){

   
    this.userDataService.setLoginStatus({loginStatus:false});
    this.userDataService.userDetails=[];
    
    this.router.navigateByUrl('login');
  }

}
