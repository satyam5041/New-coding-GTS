// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
//https://documenter.getpostman.com/view/1134062/T1LJjU52#dd5bd0d9-2602-4161-8c77-3af30cd2f41a
export const api={
  url:"http://localhost:8090/api",
  bibleApi:"http://160.153.63.66:50800/api",
  // bibleApi:"http://localhost:3000/api",
  // url:"http://localhost:80/myapp/ci3/index.php/Api",
};
export const environment = {
  production: false,
  log:false,
  SERVICE_APIS:{
    companies:api.url+"/companies",
    addCompany:api.url+"/companies/addCompany",
    updateCompany:api.url+"/companies/updateCompany",
    deleteCompany:api.url+"/companies/deleteCompany",

    user:api.url+"/user",
    deleteUser:api.url+"/user/deleteUser",
    addUser:api.url+"/user/addUser",
    updateUser:api.url+"/user/updateUser",
    changePwd:api.url+"/user/changePwd",
    checkUserIDAvailability:api.url+"/user/checkUserIDAvailability",
    validateUserDetails:api.url+"/user/validateUserDetails",

    vessel:api.url+"/vessel",
    deleteVessel:api.url+"/vessel/deleteVessel",
    addVessel:api.url+"/vessel/addVessel",
    updateVessel:api.url+"/vessel/updateVessel",

    ports:api.url+"/ports",
    deletePort:api.url+"/ports/deletePort",
    addPort:api.url+"/ports/addPort",
    updatePort:api.url+"/ports/updatePort",

    countries:api.url+"/countries",
    deleteCountry:api.url+"/countries/deleteCountry",
    addCountry:api.url+"/countries/addCountry",
    updateCountry:api.url+"/countries/updateCountry",

    currencies:api.url+"/currencies",
    deleteCurrency:api.url+"/currencies/deleteCurrency",
    addCurrency:api.url+"/currencies/addCurrency",
    updateCurrency:api.url+"/currencies/updateCurrency",


    getCountries:"https://countriesnow.space/api/v0.1/countries",


    createUser:api.url+"/createUser",
    profileUpdate:api.url+"/profileUpdate",
    validateUser:api.url+"/validateUser",    
    relationUpdate:api.url+"/relationUpdate",
    getFamilyMembers:api.url+"/getFamilyMembers",
    prayerRequest:api.url+"/prayerRequest",    
    pwdUpdate:api.url+"/pwdUpdate",
    getAttendanceStatus:api.url+"/getAttendanceStatus",
    createAttendance:api.url+"/createAttendance",
    getAnnouncements:api.url+"/getAnnouncements",
    getVideos:api.url+"/getVideos",
    avatarUpdate:api.url+"/avatarUpdate",
      promiseCreateForUser:api.url+"/promiseCreateForUser",
      getUserPromises:api.url+"/getUserPromises",
      getTodaySongs:api.url+"/getTodaySongs",
      updateNotificationStatus:api.url+"/updateNotificationStatus",
      createGoal:api.url+"/createGoal",
      getGoals:api.url+"/getGoals",
      createSuggestion:api.url+"/createSuggestion",
      getWeeklyServices:api.url+"/getWeeklyServices",
      getPrayerList:api.url+"/getPrayerList",      
      updatePrayerAsAnswered:api.url+"/updatePrayerAsAnswered",
      getChurchInfor:api.url+"/getChurchInfor",
      subscribeToChurch:api.url+"/subscribeToChurch",
      todaySongCreate:api.url+"/todaySongCreate",
      getProducts:api.url+"/getProducts",
      createPODetails:api.url+"/createPODetails",
      getPurchasedCustomerDetails:api.url+"/getPurchasedCustomerDetails",
      getCostomerCartView:api.url+"/getCostomerCartView",
      getCostomerCartViewTracking:api.url+"/getCostomerCartViewTracking",
      getLeadershipOrTestimonies:api.url+"/getLeadershipOrTestimonies",
      getGallery:api.url+"/getGallery",
      jobRequest:api.url+"/jobRequest",
      getCorporateJobs:api.url+"/getCorporateJobs",
      matrimonyRequest:api.url+"/matrimonyRequest",
      getChainPrayerList:api.url+"/getChainPrayerList",
      createChainPrayerList:api.url+"/createChainPrayerList",
      getChainPrayerDetails:api.url+"/getChainPrayerDetails",
      getChainPrayer:api.url+"/getChainPrayer",
      updateChainPrayerList:api.url+"/updateChainPrayerList",
      getQuizList:api.url+"/getQuizList",
      getQuizCompletedList:api.url+"/getQuizCompletedList",
      getQuizQuestionList:api.url+"/getQuizQuestionList",
      updateQuiz:api.url+"/updateQuiz",
      getQuizAnswerList:api.url+"/getQuizAnswerList",
      getMemoryVerses:api.url+"/getMemoryVerses",
      getSeminarList:api.url+"/getSeminarList",
      getSeminarDetailedList:api.url+"/getSeminarDetailedList",
      getTheme:api.url+"/getTheme",
      getForumList:api.url+"/getForumList",
      createForum:api.url+"/createForum",
      getForumListDetails:api.url+"/getForumListDetails",
      createForumReplies:api.url+"/createForumReplies",

      getBibleVerse:api.bibleApi+"/getBibleVerse",
      getbibleBooks:api.bibleApi+"/getbibleBooks",
      addNotes:api.bibleApi+"/addNotes",
      getBibleNotes:api.bibleApi+"/getBibleNotes",
      createBibleTheme:api.bibleApi+"/createBibleTheme",
      deleteBibleNote:api.bibleApi+"/deleteBibleNote",
      getBibleThemes:api.bibleApi+"/getBibleThemes",
      getBibleNotesWithThemeId:api.bibleApi+"/getBibleNotesWithThemeId",
  }
 
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
