export const environment = {
  production: true,
  SERVICE_APIS:{
    createUser:"http://rmeti.com/pgm-app/index.php/Api/createUser",
    profileUpdate:"http://rmeti.com/pgm-app/index.php/Api/profileUpdate",
    validateUser:"http://rmeti.com/pgm-app/index.php/Api/validateUser",
    relationUpdate:"http://rmeti.com/pgm-app/index.php/Api/relationUpdate",
    getFamilyMembers:"http://rmeti.com/pgm-app/index.php/Api/getFamilyMembers",
    prayerRequest:"http://rmeti.com/pgm-app/index.php/Api/prayerRequest",
    pwdUpdate:"http://rmeti.com/pgm-app/index.php/Api/pwdUpdate",
  }
};
